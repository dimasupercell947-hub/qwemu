import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const required = [
  'RUN_QWEMU.bat',
  'BUILD_EXE.bat',
  'SETUP_RUST_TOOLCHAIN.bat',
  'LOAD_MSVC_ENV.bat',
  'DIAGNOSE_QWEMU.bat',
];
const failures = [];
let passed = 0;
const check = (name, condition, detail = '') => {
  if (condition) {
    passed += 1;
    console.log(`PASS | ${name}`);
  } else {
    failures.push({ name, detail });
    console.log(`FAIL | ${name}${detail ? ` | ${detail}` : ''}`);
  }
};

const files = {};
for (const name of required) {
  const filePath = path.join(root, name);
  check(`Required BAT exists: ${name}`, fs.existsSync(filePath));
  if (!fs.existsSync(filePath)) continue;
  const raw = fs.readFileSync(filePath);
  const text = raw.toString('ascii');
  files[name] = text;
  check(`${name}: ASCII without BOM`, raw.equals(Buffer.from(text, 'ascii')) && raw[0] !== 0xef);
  check(`${name}: Windows CRLF only`, text.includes('\r\n') && !/(^|[^\r])\n/.test(text));
  check(`${name}: no delayed expansion`, !/EnableDelayedExpansion/i.test(text) && !/![A-Za-z_][A-Za-z0-9_]*!/.test(text));
  const labels = new Set([...text.matchAll(/^:([A-Za-z0-9_]+)\s*$/gm)].map(match => match[1].toLowerCase()));
  const references = [...text.matchAll(/\b(?:goto|call)\s+:([A-Za-z0-9_]+)/gi)]
    .map(match => match[1].toLowerCase())
    .filter(label => label !== 'eof');
  const missingLabels = [...new Set(references)].filter(label => !labels.has(label));
  check(`${name}: all GOTO/CALL labels exist`, missingLabels.length === 0, missingLabels.join(', '));
}

for (const name of ['RUN_QWEMU.bat', 'BUILD_EXE.bat', 'SETUP_RUST_TOOLCHAIN.bat', 'DIAGNOSE_QWEMU.bat']) {
  const text = files[name] ?? '';
  check(`${name}: isolates variables without delayed expansion`, /setlocal\s+EnableExtensions\s+DisableDelayedExpansion/i.test(text));
  check(`${name}: uses pushd for local/UNC project paths`, /pushd\s+"%~dp0"/i.test(text) && /popd/i.test(text));
}

const run = files['RUN_QWEMU.bat'] ?? '';
check('RUN: validates the complete Tauri project', ['package.json', 'src-tauri\\Cargo.toml', 'src-tauri\\tauri.conf.json', 'web\\index.html'].every(value => run.includes(value)));
check('RUN: resolves Cargo and Rustup homes before setup', /if not defined CARGO_HOME set/i.test(run) && /if not defined RUSTUP_HOME set/i.test(run) && /%CARGO_HOME%\\bin/i.test(run));
check('RUN: checks dependencies instead of trusting only the tauri.cmd shim', run.includes('npm.cmd ls @tauri-apps/cli --depth=0') && run.includes(':ensure_dependencies'));
check('RUN: uses npm ci when a lockfile exists and install otherwise', run.includes('npm.cmd ci --no-audit --no-fund') && run.includes('npm.cmd install --no-audit --no-fund'));
check('RUN: validates project before starting Tauri dev', run.indexOf('npm.cmd run check') >= 0 && run.indexOf('npm.cmd run check') < run.indexOf('npm.cmd run dev'));
check('RUN: captures the Tauri process exit code', /set "APP_RC=%ERRORLEVEL%"/.test(run) && run.includes('%APP_RC%'));
check('RUN and BUILD: select the exact Rust MSVC toolchain after setup', ['RUN_QWEMU.bat','BUILD_EXE.bat'].every(name => (files[name] ?? '').includes('set "RUSTUP_TOOLCHAIN=stable-x86_64-pc-windows-msvc"')));

const build = files['BUILD_EXE.bat'] ?? '';
check('BUILD: invokes Rust/MSVC environment helpers', build.includes('SETUP_RUST_TOOLCHAIN.bat') && build.includes('LOAD_MSVC_ENV.bat'));
check('BUILD: executes checks before packaging in correct order',
  build.indexOf('npm.cmd run check\r\n') < build.indexOf('npm.cmd run check:rust:fmt\r\n') &&
  build.indexOf('npm.cmd run check:rust:fmt\r\n') < build.indexOf('npm.cmd run check:rust\r\n') &&
  build.indexOf('npm.cmd run check:rust\r\n') < build.indexOf('npm.cmd run test:rust\r\n') &&
  build.indexOf('npm.cmd run test:rust\r\n') < build.indexOf('npm.cmd run build\r\n'));
check('BUILD: searches Tauri target-specific bundle subdirectories recursively', /for \/r "%BUNDLE_DIR%" %%F in \(\*\.msi\)/i.test(build) && /for \/r "%BUNDLE_DIR%" %%F in \(\*\.exe\)/i.test(build));
check('BUILD: requires both configured MSI and NSIS EXE installers', build.includes('if not defined MSI_FOUND goto :msi_missing') && build.includes('if not defined NSIS_FOUND goto :nsis_missing'));
check('BUILD: does not incorrectly search only the bundle root', !/dir \/b\s+"[^"\r\n]*bundle\\\*\.(?:msi|exe)"/i.test(build));
check('BUILD: verifies actual bundle directory after successful Tauri exit', build.includes('if not exist "%BUNDLE_DIR%" goto :bundle_missing') && build.includes('set "BUILD_RC=%ERRORLEVEL%"'));
check('BUILD: records a pre-build timestamp and verifies fresh MSI/NSIS outputs', build.includes('QWEMU_BUILD_STAMP') && build.includes('QWEMU_BUNDLE_DIR') && build.includes('LastWriteTimeUtc.Ticks -ge $stampTicks') && build.includes('UtcNow.Ticks') && build.includes('InvariantCulture') && !build.includes('AddSeconds(-2)') && build.includes(':artifact_stale'));
check('BUILD: removes temporary build stamp on success and failure', build.includes('if defined QWEMU_BUILD_STAMP if exist "%QWEMU_BUILD_STAMP%" del'));

const setup = files['SETUP_RUST_TOOLCHAIN.bat'] ?? '';
check('RUST SETUP: downloads the official Windows MSVC rustup installer', setup.includes('https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/rustup-init.exe'));
check('RUST SETUP: installs rustup without forcing an immediate stable-channel download', setup.includes('--default-toolchain none'));
check('RUST SETUP: pins the exact Windows MSVC host toolchain', setup.includes('set "QWEMU_TOOLCHAIN=stable-x86_64-pc-windows-msvc"'));
check('RUST SETUP: checks locally installed MSVC toolchains before attempting network installation', setup.includes('toolchain list > "%TOOLCHAIN_LIST%"') && setup.indexOf('toolchain list >') < setup.indexOf(':install_stable') && setup.includes('if /i "%%T"=="%QWEMU_TOOLCHAIN%" set "TOOLCHAIN_FOUND=1"'));
check('RUST SETUP: matches the full toolchain token, not a similarly prefixed GNU/nightly toolchain', setup.includes('for /f "usebackq tokens=1" %%T in ("%TOOLCHAIN_LIST%")') && setup.includes('if not defined TOOLCHAIN_FOUND goto :install_stable') && !setup.includes('findstr /i /l /b "%QWEMU_TOOLCHAIN%"'));
const exactToolchainToken = (list, wanted = 'stable-x86_64-pc-windows-msvc') => list.split(/\r?\n/).some(line => line.trim().split(/\s+/)[0]?.toLowerCase() === wanted.toLowerCase());
check('RUST SETUP: exact parser accepts installed MSVC stable with rustup status suffix', exactToolchainToken('stable-x86_64-pc-windows-msvc (default)\n1.89.0-x86_64-pc-windows-msvc'));
check('RUST SETUP: exact parser rejects a GNU toolchain with a shared stable prefix', !exactToolchainToken('stable-x86_64-pc-windows-gnu (default)'));
check('RUST SETUP: exact parser rejects nightly/MSVC names with a shared prefix', !exactToolchainToken('stable-x86_64-pc-windows-msvc-nightly (default)'));
check('RUST SETUP: never falls back to ambiguous stable channel alias', !/toolchain install stable(?:\s|$)/i.test(setup) && !/--toolchain stable(?:\s|$)/i.test(setup));
check('RUST SETUP: reuses an installed stable toolchain without contacting the update server', setup.includes('Local stable toolchain found. Skipping network update') && setup.includes('goto :stable_ready'));
check('RUST SETUP: only updates an existing stable toolchain when explicitly requested', setup.includes('if "%QWEMU_UPDATE_RUST_STABLE%"=="1" goto :install_stable'));
check('RUST SETUP: checks whether rustfmt is installed before downloading it', setup.includes('component list --installed --toolchain %QWEMU_TOOLCHAIN%') && setup.includes('findstr /i /b "rustfmt-"'));
check('RUST SETUP: checks whether the MSVC target is installed before downloading it', setup.includes('target list --installed --toolchain %QWEMU_TOOLCHAIN%') && setup.includes('findstr /i /x "x86_64-pc-windows-msvc"'));
check('RUST SETUP: retries rustup operations three times with a delay', setup.includes('RUSTUP_ATTEMPT') && setup.includes('GEQ 3') && setup.includes('timeout /t 4 /nobreak'));
check('RUST SETUP: retries the initial rustup installer download three times', setup.includes('for($attempt=1;$attempt -le 3;$attempt++)') && setup.includes('Start-Sleep -Seconds 4'));
check('RUST SETUP: safely builds the installer path for TEMP directories with spaces', setup.includes('Join-Path $env:TEMP') && setup.includes('Test-Path -LiteralPath $installer'));
check('RUST SETUP: explains network/proxy/firewall failures', setup.includes('static.rust-lang.org') && setup.includes('proxy/VPN/firewall'));
check('RUST SETUP: installs stable, rustfmt and Windows MSVC target when missing', setup.includes('toolchain install %QWEMU_TOOLCHAIN% --profile minimal') && setup.includes('component add rustfmt --toolchain %QWEMU_TOOLCHAIN%') && setup.includes('target add x86_64-pc-windows-msvc --toolchain %QWEMU_TOOLCHAIN%'));
check('RUST SETUP: verifies Cargo, rustc and rustfmt using the pinned MSVC toolchain', ['cargo','rustc','rustfmt'].every(tool => setup.includes('run %QWEMU_TOOLCHAIN% '+tool+' --version')));
check('RUST SETUP: does not persistently modify rustup project overrides', !setup.includes('override set stable'));
check('RUST SETUP: removes downloaded installer after use/failure', setup.includes('del /q "%RUSTUP_INSTALLER%"'));

const msvc = files['LOAD_MSVC_ENV.bat'] ?? '';
check('MSVC: intentionally preserves VsDevCmd environment changes', !/^\s*setlocal\b/im.test(msvc) && msvc.includes('VsDevCmd.bat'));
check('MSVC: initializes Visual Studio for x64 host and target', msvc.includes('-arch=x64 -host_arch=x64'));
check('MSVC: verifies compiler, linker, Windows SDK and x64 target', msvc.includes('where cl.exe') && msvc.includes('where link.exe') && msvc.includes('WindowsSdkDir') && msvc.includes('VSCMD_ARG_TGT_ARCH'));
check('MSVC: retries Visual Studio initialization when a stale x64 environment is incomplete', msvc.includes('if errorlevel 1 goto :locate_vs') && msvc.includes('if not defined WindowsSdkDir goto :locate_vs'));
check('MSVC: verifies real Windows SDK headers and x64 libraries, not just environment variables', msvc.includes('Windows.h') && msvc.includes('kernel32.lib') && msvc.includes('ucrt.lib') && msvc.includes('QWEMU_SDK_ROOT:~-1') && msvc.includes('QWEMU_SDK_VERSION:~-1') && msvc.includes('if not defined INCLUDE') && msvc.includes('if not defined LIB'));
check('MSVC: clears only its temporary helper variables', msvc.includes('set "QWEMU_VSWHERE="') && msvc.includes('set "QWEMU_VSROOT="') && msvc.includes('set "QWEMU_VSDEVCMD="'));

const diagnose = files['DIAGNOSE_QWEMU.bat'] ?? '';
check('DIAGNOSE: writes a diagnostic log next to the project', diagnose.includes('diag_cargo_check.log'));
check('DIAGNOSE: initializes MSVC before Rust checks', diagnose.indexOf('LOAD_MSVC_ENV.bat') >= 0 && diagnose.indexOf('LOAD_MSVC_ENV.bat') < diagnose.indexOf('cargo check --manifest-path'));
check('DIAGNOSE: tests the same pinned Windows MSVC toolchain as launcher/build', diagnose.includes('set "QWEMU_TOOLCHAIN=stable-x86_64-pc-windows-msvc"') && diagnose.includes('rustup.exe run %QWEMU_TOOLCHAIN% rustc -Vv') && diagnose.includes('rustup.exe run %QWEMU_TOOLCHAIN% cargo -V') && diagnose.includes('rustfmt --version'));
check('DIAGNOSE: invokes fmt/check/test through the exact rustup MSVC toolchain', ['cargo fmt --check','cargo check','cargo test'].every(command => diagnose.includes('rustup.exe run %QWEMU_TOOLCHAIN% '+command)) && !/^cargo (?:fmt|check|test)/m.test(diagnose));
check('DIAGNOSE: skips native compilation/tests when MSVC or Windows SDK setup fails', diagnose.includes('if not "%MSVC_RC%"=="0" goto :rust_compile_unavailable') && diagnose.includes('[SKIPPED] Cargo check/test require a valid MSVC'));
check('DIAGNOSE: records MSVC compiler version and SDK environment for useful reports', diagnose.includes('cl.exe /Bv') && diagnose.includes('WindowsSDKVersion=%WindowsSDKVersion%') && diagnose.includes('INCLUDE=%INCLUDE%') && diagnose.includes('LIB=%LIB%'));
check('DIAGNOSE: records separate exit codes for frontend, MSVC, fmt, check and tests', ['FRONT_RC', 'MSVC_RC', 'FMT_RC', 'CARGO_RC', 'TEST_RC'].every(value => diagnose.includes(value)));
check('DIAGNOSE: fails when a required tool or project file is missing', diagnose.includes(':node_missing') && diagnose.includes(':npm_missing') && diagnose.includes(':rustup_missing') && diagnose.includes('[MISSING]'));
check('DIAGNOSE: returns a failure exit code when checks fail', diagnose.includes(':failed') && /exit \/b 1/.test(diagnose));

const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const scripts = new Set(Object.keys(packageJson.scripts ?? {}));
for (const [name, text] of Object.entries(files)) {
  const commands = [...text.matchAll(/call\s+npm\.cmd\s+run\s+([A-Za-z0-9:_-]+)/gi)].map(match => match[1]);
  for (const command of new Set(commands)) {
    check(`${name}: npm script exists in package.json (${command})`, scripts.has(command));
  }
  check(`${name}: npm batch commands use CALL`, !/(?<!call\s)npm\.cmd\s+(?:run|install|ci|ls)/i.test(text));
}

console.log(`\nBAT AUDIT: ${passed} passed, ${failures.length} failed, ${passed + failures.length} total.`);
if (failures.length) process.exit(1);
