import fs from 'node:fs';
import assert from 'node:assert/strict';
const rust = fs.readFileSync(new URL('../src-tauri/src/main.rs', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../web/index.html', import.meta.url), 'utf8');
const checks = [
  ['site validation command', /fn qwemu_check_music_site\(/.test(rust)],
  ['AI search command', /fn qwemu_ai_music_search\(/.test(rust)],
  ['OpenAI Responses API', /api\.openai\.com\/v1\/responses/.test(rust)],
  ['web search tool', /"type":\s*"web_search"/.test(rust)],
  ['secret is read from environment', /OPENAI_API_KEY/.test(rust)],
  ['response storage disabled', /"store":\s*false/.test(rust)],
  ['site domain filter', /host_is_same_site/.test(rust)],
  ['supported audio URL validation', /audio_extension_from_url\(url\)\.is_ok\(\)/.test(rust)],
  ['commands registered with Tauri', /qwemu_check_music_site,\s*qwemu_ai_config_status,\s*qwemu_ai_music_search/.test(rust)],
  ['AI search UI', /QWEMU AI Music Finder/.test(html) && /ai-music-search/.test(html)],
  ['explicit selected import', /qwemuAddAiSelected/.test(html) && /ai-add-selected/.test(html)],
  ['source opening action', /data-ai-open/.test(html)],
  ['existing direct URL import retained', /download_audio_from_url/.test(rust) && /link-import-form/.test(html)],
  ['existing browser retained', /open_qwemu_browser/.test(rust) && /open-qwemu-browser/.test(html)],
];
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); assert.ok(ok, name); }
console.log(`AI Music Finder checks: ${checks.length}/${checks.length} passed`);
