import fs from 'node:fs';
import assert from 'node:assert/strict';
const rust=fs.readFileSync(new URL('../src-tauri/src/main.rs',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../web/index.html',import.meta.url),'utf8');
const checks=[
  ['AI configuration status command exists',/fn qwemu_ai_config_status\(/.test(rust)],
  ['AI configuration status is registered',/qwemu_check_music_site,\s*qwemu_ai_config_status,\s*qwemu_ai_music_search/.test(rust)],
  ['Search endpoint returns structured metadata',/struct MusicSearchResponse/.test(rust)&&/source_count:\s*usize/.test(rust)&&/elapsed_ms:\s*u64/.test(rust)],
  ['Search mode is validated on Rust side',/"exact"\s*=>\s*"exact"/.test(rust)&&/"discovery"\s*=>\s*"discovery"/.test(rust)&&/"album"\s*=>\s*"album"/.test(rust)],
  ['Result limit is clamped',/limit\.unwrap_or\(12\)\.clamp\(3, 20\)/.test(rust)],
  ['Web Search restricts allowed domain server-side',/"filters":\s*\{\s*"allowed_domains":\s*\[host\]\s*\}/.test(rust)],
  ['Web Search is required for every AI lookup',/\"tool_choice\":\s*\"required\"/.test(rust)],
  ['Web Search source metadata is requested',/web_search_call\.action\.sources/.test(rust)&&/fn response_music_sources\(/.test(rust)],
  ['Candidate metadata includes year and genre',/year:\s*String/.test(rust)&&/genre:\s*String/.test(rust)],
  ['Candidate metadata includes match explanation',/match_reason:\s*String/.test(rust)],
  ['Untrusted candidate page URLs are filtered after response',/candidates\.retain\(\|candidate\|/.test(rust)&&/host_is_same_site\(&page, &host\)/.test(rust)],
  ['Direct audio URLs remain same-site and format checked',/audio_extension_from_url\(url\)\.is_ok\(\)/.test(rust)&&/candidate\.audio_url = valid/.test(rust)],
  ['OpenAI response size is bounded',/3 \* 1024 \* 1024/.test(rust)&&/read_to_end\(&mut response_bytes\)/.test(rust)],
  ['OpenAI error classes show actionable hints',/401 => " Проверь API-ключ/.test(rust)&&/429 => " Проверь лимиты запросов/.test(rust)],
  ['OpenAI response storage remains disabled',/"store":\s*false/.test(rust)],
  ['Frontend supports exact, discovery and album modes',/value="exact"/.test(html)&&/value="discovery"/.test(html)&&/value="album"/.test(html)],
  ['Frontend supports result limits and sorting',/id="qwemu-ai-limit"/.test(html)&&/id="qwemu-ai-sort"/.test(html)],
  ['Remix inclusion is optional',/id="qwemu-ai-remixes"/.test(html)&&/includeRemixes/.test(html)],
  ['AI search history is persistent and clearable',/qwemu-ai-search-history-v1/.test(html)&&/ai-clear-history/.test(html)],
  ['Duplicate matches are detected before import',/function qwemuAiIsDuplicate\(/.test(html)&&/fresh=selected\.filter\(index=>!qwemuAiIsDuplicate/.test(html)],
  ['Source and candidate metadata are shown',/sourceCount/.test(html)&&/matchReason/.test(html)&&/item\.year/.test(html)&&/item\.genre/.test(html)],
  ['Batch selection actions exist',/ai-select-all/.test(html)&&/ai-select-none/.test(html)],
  ['AI key is not placed into frontend source',!/OPENAI_API_KEY\s*[:=]\s*["'][^"']{16,}["']/.test(html)],
  ['Tauri production frontend is the single HTML source',html.includes('QWEMU_NATIVE')],
  ['Stage 3 direct URL import and browser hooks remain',/download_audio_from_url/.test(rust)&&/open_qwemu_browser/.test(rust)&&/link-import-form/.test(html)],
  ['Existing FLOW, EQ, playlists and playback hooks remain',/pulsePage\(/.test(html)&&/audio_set_eq/.test(html)&&/playlistsPage\(/.test(html)&&/audio_play/.test(rust)],
];
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);assert.ok(ok,name);}
console.log(`AI Music Finder PRO checks: ${checks.length}/${checks.length} passed`);
