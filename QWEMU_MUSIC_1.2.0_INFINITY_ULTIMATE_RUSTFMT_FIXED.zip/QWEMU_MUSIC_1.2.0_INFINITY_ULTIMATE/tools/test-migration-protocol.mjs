import assert from 'node:assert/strict';
import { createHash, webcrypto } from 'node:crypto';

const CHUNK_SIZE = 192 * 1024;
const bytes = Uint8Array.from({ length: CHUNK_SIZE + 37 }, (_, index) => (index * 31 + 17) & 0xff);
const expectedWholeHash = createHash('sha256').update(bytes).digest('hex');
let written = 0;
const received = [];

for (let offset = 0; offset < bytes.length; offset += CHUNK_SIZE) {
  const end = Math.min(offset + CHUNK_SIZE, bytes.length);
  const chunk = bytes.slice(offset, end);
  const digest = await webcrypto.subtle.digest('SHA-256', chunk);
  const chunkHash = Buffer.from(digest).toString('hex');
  const base64 = Buffer.from(chunk).toString('base64');
  const decoded = Buffer.from(base64, 'base64');

  assert.equal(offset, written, 'chunk offsets must be contiguous');
  assert.ok(decoded.length > 0 && decoded.length <= CHUNK_SIZE, 'chunk size must stay within Rust limit');
  assert.equal(createHash('sha256').update(decoded).digest('hex'), chunkHash, 'Base64 round-trip must preserve chunk SHA-256');
  received.push(decoded);
  written += decoded.length;
}

const reconstructed = Buffer.concat(received);
assert.equal(written, bytes.length, 'received size must equal source size');
assert.equal(createHash('sha256').update(reconstructed).digest('hex'), expectedWholeHash, 'reconstructed file hash must match source');

const firstChunk = bytes.slice(0, CHUNK_SIZE);
const wrongHash = '0'.repeat(64);
assert.notEqual(createHash('sha256').update(firstChunk).digest('hex'), wrongHash, 'wrong chunk digest must be rejected');
const expectedNextOffset = CHUNK_SIZE;
const outOfOrderOffset = expectedNextOffset + 1;
const validateOffset = (actual, expected) => { if (actual !== expected) throw new Error('offset mismatch'); };
assert.throws(() => validateOffset(outOfOrderOffset, expectedNextOffset), /offset mismatch/, 'out-of-order offset must be rejected');

console.log('PASS | 192 KiB chunk boundary and final partial chunk');
console.log('PASS | WebCrypto SHA-256 matches Node SHA-256');
console.log('PASS | Base64 chunk round-trip');
console.log('PASS | contiguous offset and exact total size');
console.log('PASS | mismatched chunk digest is detectable');
console.log(`PASS | full file SHA-256 ${expectedWholeHash}`);
