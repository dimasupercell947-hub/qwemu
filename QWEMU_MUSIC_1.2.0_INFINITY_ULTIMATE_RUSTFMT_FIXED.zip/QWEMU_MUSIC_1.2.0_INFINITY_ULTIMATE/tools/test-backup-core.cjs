'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const core = require('../web/assets/backup-core.js');
let passed = 0;
function check(name, fn) { fn(); passed++; console.log(`PASS | ${name}`); }
const valid = {
  app: 'QWEMU', version: '1.2.0', exportedAt: '2026-11-18T18:00:00.000Z',
  account: { username: 'ignore-this', email: 'private@example.invalid' },
  metadata: {
    favorites: ['track-a', 'track-a', 'track-b'], history: ['track-b'],
    searchHistory: ['ambient'], queueIds: ['track-a'], queueIndex: 0,
    playlists: [{ id: 'list-1', name: 'Focus', description: 'Work', trackIds: ['track-a'] }],
    prefs: { accent: '#ff5522', compact: true, animations: false },
    shuffle: true, repeat: 'all', volume: 0.5,
    accessToken: 'must-not-be-restored', nativePath: 'C:\\private\\music.mp3'
  },
  audioSettings: { masterVolume: 0.7, uiVolume: 0.2, eqBands: [1,2,3,4,5,6,7,8,9,10], customEQ: [0,0,0,0,0,0,0,0,0,0], muted: false }
};
check('Valid 1.2.0 backup is normalized', () => {
  const result = core.normalizeBackup(valid);
  assert.equal(result.sourceVersion, '1.2.0');
  assert.deepEqual(result.metadata.favorites, ['track-a', 'track-b']);
  assert.equal(result.metadata.playlists[0].name, 'Focus');
  assert.equal(result.audioSettings.eqBands.length, 10);
});
check('Legacy 1.1.0 backup remains importable', () => {
  const result = core.normalizeBackup({ app: 'QWEMU', version: '1.1.0', metadata: { favorites: ['x'] } });
  assert.deepEqual(result.metadata.favorites, ['x']);
  assert.equal(result.audioSettings, null);
});
check('Wrong app and unsupported versions are rejected', () => {
  assert.throws(() => core.normalizeBackup({ ...valid, app: 'OTHER' }), /не резервная копия/);
  assert.throws(() => core.normalizeBackup({ ...valid, version: '9.9.9' }), /не поддерживается/);
});
check('Malformed metadata is rejected', () => {
  assert.throws(() => core.normalizeBackup({ app: 'QWEMU', version: '1.2.0', metadata: [] }), /metadata/);
});
check('Volume and EQ values are safely clamped', () => {
  const result = core.normalizeBackup({ ...valid, audioSettings: { masterVolume: 9, uiVolume: -2, eqBands: Array(10).fill(99) } });
  assert.equal(result.audioSettings.masterVolume, 1);
  assert.equal(result.audioSettings.uiVolume, 0);
  assert.equal(result.audioSettings.eqBands[0], 12);
});
check('Non-boolean preference values cannot enable flags', () => {
  const result = core.normalizeBackup({ ...valid, metadata: { prefs: { compact: 'false' }, shuffle: 'false', repeat: 'all' } });
  assert.equal(result.metadata.prefs.compact, false);
  assert.equal(result.metadata.shuffle, false);
  assert.equal(result.metadata.repeat, 'all');
});
check('Playlist fields are bounded and invalid entries are removed', () => {
  const result = core.normalizeBackup({ ...valid, metadata: { playlists: [{ id: 'x', name: 'ok', trackIds: ['a'] }, { id: '', name: 'invalid' }] } });
  assert.equal(result.metadata.playlists.length, 1);
  assert.deepEqual(result.metadata.playlists[0].trackIds, ['a']);
});
check('Restore merges instead of deleting existing favorites and playlists', () => {
  const merged = core.mergeMetadata({ favorites: ['local'], playlists: [{ id: 'p', name: 'Local', trackIds: ['local-track'] }] }, { favorites: ['imported'], playlists: [{ id: 'p', name: 'Imported', trackIds: ['remote-track'] }] });
  assert.deepEqual(merged.favorites, ['local', 'imported']);
  assert.deepEqual(merged.playlists[0].trackIds, ['local-track', 'remote-track']);
});
check('Backup import does not copy tokens or local filesystem paths', () => {
  const result = core.normalizeBackup(valid);
  assert.equal('accessToken' in result.metadata, false);
  assert.equal('nativePath' in result.metadata, false);
});
check('Remote URL validator rejects local and non-web schemes', () => {
  assert.equal(core.safeHttpUrl('file:///C:/private/audio.mp3'), '');
  assert.equal(core.safeHttpUrl('http://127.0.0.1/audio.mp3'), '');
  assert.equal(core.safeHttpUrl('http://[::1]/audio.mp3'), '');
  assert.equal(core.safeHttpUrl('http://files.local/audio.mp3'), '');
  assert.equal(core.safeHttpUrl('https://example.com/audio.mp3'), 'https://example.com/audio.mp3');
});
check('Packaged frontend includes the backup core', () => {
  assert.ok(fs.existsSync(path.join(__dirname, '../web/assets/backup-core.js')));
  assert.match(fs.readFileSync(path.join(__dirname, '../web/index.html'), 'utf8'), /assets\/backup-core\.js/);
});
console.log(`Backup core: ${passed}/${passed} PASS`);
