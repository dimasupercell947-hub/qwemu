import fs from 'node:fs';
import assert from 'node:assert/strict';
const html=fs.readFileSync(new URL('../web/index.html',import.meta.url),'utf8');
assert.match(html,/Нативное ядро QWEMU не запущено/);
assert.match(html,/Не открывай index\.html напрямую/);
assert.match(html,/Запусти RUN_QWEMU\.bat/);
assert.match(html,/if\(!QWEMU_NATIVE\)/);
console.log('Startup runtime guard: 4/4 PASS');
