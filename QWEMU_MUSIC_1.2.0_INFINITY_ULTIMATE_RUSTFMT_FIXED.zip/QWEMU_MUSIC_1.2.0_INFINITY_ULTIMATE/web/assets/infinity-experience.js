/* QWEMU MUSIC 1.1.0 — Infinity Experience additions. Uses existing app state and handlers. */
(()=>{'use strict';
 const MODE_KEY='qwemu-flow-mode-v2', PREF_KEY='qwemu-flow-preferences-v2';
 const modes=[['daily','FLOW Daily','Твой привычный музыкальный ритм'],['discovery','FLOW Discovery','Меньше повторов, больше открытий'],['favorites','FLOW Favorites','Вокруг любимых композиций'],['underground','FLOW Underground','Редко проигрываемые находки'],['random','FLOW Random','Перемешанная подборка']];
 const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key)||'null')??fallback}catch{return fallback}};
 let mode=read(MODE_KEY,'daily'); if(!modes.some(x=>x[0]===mode))mode='daily';
 let prefs=read(PREF_KEY,{excludedArtists:[],excludedGenres:[],hidePlayed:false});
 const norm=v=>String(v||'').trim().toLocaleLowerCase('ru');
 const persist=()=>{try{localStorage.setItem(MODE_KEY,JSON.stringify(mode));localStorage.setItem(PREF_KEY,JSON.stringify(prefs));}catch(e){console.warn('FLOW preferences not persisted',e)}};
 const baseRecommendations=typeof pulseRecommendations==='function'?pulseRecommendations:null;
 function picks(){if(!baseRecommendations)return[];let all=baseRecommendations().filter(x=>!prefs.excludedArtists.includes(norm(x.track.artist))&&!prefs.excludedGenres.includes(norm(x.track.genre))&&(!prefs.hidePlayed||!state.history.includes(x.track.id)));
  if(mode==='favorites')all=all.filter(x=>state.favorites.includes(x.track.id));
  if(mode==='discovery')all.sort((a,b)=>Number(state.history.includes(a.track.id))-Number(state.history.includes(b.track.id))||a.score-b.score);
  if(mode==='underground')all.sort((a,b)=>(state.history.filter(id=>id===a.track.id).length-state.history.filter(id=>id===b.track.id).length)||a.score-b.score);
  if(mode==='random'){let seed=(new Date().getDate()*9301+new Date().getMonth()*49297)%233280;all=all.slice().sort((a,b)=>{seed=(seed*9301+49297)%233280;const x=seed/233280;seed=(seed*9301+49297)%233280;return x-seed/233280;});}
  return all.slice(0,12);
 }
 function controls(){return `<section class="infinity-flow-controls"><div class="infinity-flow-title"><div><span class="eyebrow">INFINITY FLOW 2.0</span><h2>Выбери характер волны</h2><p>Рекомендации рассчитываются локально по твоей библиотеке и истории.</p></div><button class="secondary" type="button" data-flow-refresh>↻ Пересчитать</button></div><div class="infinity-flow-modes">${modes.map(([id,name,desc])=>`<button type="button" class="infinity-flow-mode ${mode===id?'active':''}" data-flow-mode="${id}" aria-pressed="${mode===id}"><b>${name}</b><small>${desc}</small></button>`).join('')}</div><div class="infinity-flow-preferences"><label><input type="checkbox" data-flow-hide-played ${prefs.hidePlayed?'checked':''}> Скрывать уже прослушанные</label><button class="text-btn" type="button" data-flow-exclusions>Настроить исключения</button></div></section>`;}
 const basePulsePage=typeof pulsePage==='function'?pulsePage:null;
 if(basePulsePage){pulsePage=function(){const original=basePulsePage();const start=original.indexOf('<div class="section-head"');return controls()+original;};}
 const originalPicks=baseRecommendations;
 if(originalPicks){pulseRecommendations=function(){return picks();};}
 document.addEventListener('click',e=>{
  const m=e.target.closest('[data-flow-mode]');if(m){mode=m.dataset.flowMode;persist();if(state.page==='pulse')render();return;}
  if(e.target.closest('[data-flow-refresh]')){if(state.page==='pulse')render();return;}
  if(e.target.closest('[data-flow-exclusions]')){const artists=prompt('Исполнители, которых исключить (через запятую):',prefs.excludedArtists.join(', '));if(artists===null)return;const genres=prompt('Жанры, которые исключить (через запятую):',prefs.excludedGenres.join(', '));if(genres===null)return;prefs.excludedArtists=artists.split(',').map(norm).filter(Boolean);prefs.excludedGenres=genres.split(',').map(norm).filter(Boolean);persist();if(state.page==='pulse')render();return;}
  if(e.target.closest('[data-playlist-export]')){const p=state.playlists.find(x=>x.id===e.target.closest('[data-playlist-export]').dataset.playlistExport);if(!p)return;const tracks=p.trackIds.map(id=>state.tracks.find(t=>t.id===id)).filter(Boolean).map(t=>({title:t.title,artist:t.artist,album:t.album,duration:t.duration||0}));const blob=new Blob([JSON.stringify({format:'qwemu-playlist',version:1,name:p.name,description:p.description||'',tracks},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=(p.name||'qwemu-playlist').replace(/[\\/:*?"<>|]/g,'_')+'.qwemu-playlist.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;}
 });
 document.addEventListener('change',e=>{if(e.target.matches('[data-flow-hide-played]')){prefs.hidePlayed=e.target.checked;persist();if(state.page==='pulse')render();}});
 // Add a non-destructive playlist export action to the selected playlist header.
 const baseRender=render;
 if(typeof baseRender==='function')render=function(){baseRender();if(state.page==='playlists'){const selected=state.playlists.find(p=>p.id===state.selectedPlaylist);const head=document.querySelector('#content .section-head');if(selected&&head&&!head.querySelector('[data-playlist-export]')){const b=document.createElement('button');b.className='secondary';b.type='button';b.dataset.playlistExport=selected.id;b.textContent='⇩ Экспорт';head.querySelector('.playlist-tools')?.append(b);}}};
 window.QWEMUInfinityExperience={getFlowMode:()=>mode,setFlowMode:value=>{if(modes.some(x=>x[0]===value)){mode=value;persist();if(state.page==='pulse')render();}},getFlowPreferences:()=>({...prefs})};
})();
