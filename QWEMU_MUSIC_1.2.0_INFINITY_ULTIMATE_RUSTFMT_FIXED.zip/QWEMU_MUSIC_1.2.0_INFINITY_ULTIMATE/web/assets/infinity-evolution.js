/* QWEMU MUSIC 1.1.0 — persistent theme manager; no framework dependency. */
(()=>{'use strict';
 const KEY='qwemu-infinity-theme-v1';
 const themes=[
  {id:'dark-red',name:'Dark Red',hint:'Фирменный красно-оранжевый',swatch:'linear-gradient(135deg,#170807 50%,#ff4b32 50%)'},
  {id:'orange-night',name:'Orange Night',hint:'Тёплый янтарный акцент',swatch:'linear-gradient(135deg,#211207 50%,#ff9b22 50%)'},
  {id:'midnight',name:'Midnight',hint:'Холодный сине-фиолетовый',swatch:'linear-gradient(135deg,#090d19 50%,#9b83ff 50%)'},
  {id:'pure-black',name:'Pure Black',hint:'Чёрный OLED-стиль',swatch:'linear-gradient(135deg,#000 50%,#ff4b32 50%)'},
  {id:'light',name:'Light',hint:'Светлая тема',swatch:'linear-gradient(135deg,#fff 50%,#d83b28 50%)'},
  {id:'custom',name:'Custom Theme',hint:'Свой цвет акцента',swatch:'linear-gradient(135deg,#191018 50%,#32c99a 50%)'}
 ];
 const defaults={theme:'dark-red',accent:'#ff4b32'};
 const validColor=v=>/^#[0-9a-f]{6}$/i.test(v)?v:defaults.accent;
 function read(){try{const v=JSON.parse(localStorage.getItem(KEY)||'{}');return{theme:themes.some(t=>t.id===v.theme)?v.theme:defaults.theme,accent:validColor(v.accent)};}catch{return{...defaults};}}
 let prefs=read();
 function apply(){document.documentElement.dataset.qwemuTheme=prefs.theme;document.documentElement.style.setProperty('--qwemu-custom-accent',prefs.accent);document.querySelector('meta[name="theme-color"]')?.setAttribute('content',prefs.theme==='light'?'#f4f1ef':prefs.theme==='midnight'?'#090d19':prefs.theme==='pure-black'?'#000000':'#100605');}
 function save(){try{localStorage.setItem(KEY,JSON.stringify(prefs));}catch(error){console.warn('QWEMU theme preference could not be saved',error);}apply();renderPanel();}
 function panel(){return `<section class="qwemu-infinity-theme" id="qwemu-infinity-theme"><h3>✦ Infinity Appearance</h3><p>Выбери оформление QWEMU. Тема и собственный акцент сохраняются локально для этого профиля Windows.</p><div class="qwemu-theme-grid">${themes.map(t=>`<button type="button" class="qwemu-theme-option" data-qwemu-theme-choice="${t.id}" aria-pressed="${prefs.theme===t.id}"><span class="qwemu-theme-swatch" style="background:${t.swatch}"></span><span><b>${t.name}</b><small>${t.hint}</small></span></button>`).join('')}</div><div class="qwemu-theme-custom"><label for="qwemu-theme-accent">Свой цвет акцента</label><input id="qwemu-theme-accent" type="color" value="${prefs.accent}"><span>Применяется в режиме Custom Theme</span><span class="qwemu-theme-status" role="status">${prefs.theme==='custom'?'Собственная тема активна':'Настройки сохранены'}</span></div></section>`;}
 function renderPanel(){const host=document.getElementById('content');if(!host||!document.getElementById('qwemu-infinity-theme'))return;const old=document.getElementById('qwemu-infinity-theme');old.outerHTML=panel();}
 function ensurePanel(){const host=document.getElementById('content');if(!host)return;const isSettings=!!host.querySelector('.settings-grid,.settings-card,#qwemu-library-migration,.audio-lab');const existing=document.getElementById('qwemu-infinity-theme');if(isSettings&&!existing){const pageHead=host.querySelector('.page-head');(pageHead?.parentElement||host).insertAdjacentHTML('beforeend',panel());}else if(!isSettings&&existing)existing.remove();}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-qwemu-theme-choice]');if(!b)return;prefs.theme=b.dataset.qwemuThemeChoice;save();});
 document.addEventListener('input',e=>{if(e.target?.id!=='qwemu-theme-accent')return;prefs.accent=validColor(e.target.value);prefs.theme='custom';save();});
 const observer=new MutationObserver(()=>ensurePanel());
 function boot(){apply();const host=document.getElementById('content');if(host)observer.observe(host,{childList:true,subtree:true});ensurePanel();}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.QWEMUInfinity={getTheme:()=>({...prefs}),setTheme:id=>{if(themes.some(t=>t.id===id)){prefs.theme=id;save();}},reset:()=>{prefs={...defaults};save();}};
})();
