(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.QwemuBackup = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MAX_ARRAY = 5000;
  const MAX_PLAYLISTS = 500;
  const MAX_TEXT = 500;
  const clamp = (value, min, max, fallback) => {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
  };
  const text = (value, limit = MAX_TEXT) => typeof value === 'string' ? value.trim().slice(0, limit) : '';
  const uniqueStrings = value => Array.isArray(value)
    ? [...new Set(value.slice(0, MAX_ARRAY).filter(x => typeof x === 'string' && x.length > 0 && x.length <= 180))]
    : [];
  const safeAccent = value => /^#[0-9a-f]{6}$/i.test(String(value || '')) ? String(value) : '#ff3827';
  const safeHttpUrl = value => {
    if (typeof value !== 'string' || value.length > 2048) return '';
    try {
      const url = new URL(value);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return '';
      const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
      const localV6 = host === '::' || host === '::1' || /^(fc|fd|fe[89ab])/.test(host) || /^::ffff:(127|10|192\.168|169\.254)\./.test(host);
      if (!host || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.lan') || localV6 || host === '0.0.0.0' || /^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) || /^169\.254\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host)) return '';
      return url.href;
    } catch { return ''; }
  };
  function normalizeAudioSettings(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const bands = Array.isArray(value.eqBands) && value.eqBands.length === 10
      ? value.eqBands.map(v => clamp(v, -12, 12, 0))
      : Array(10).fill(0);
    const customEQ = Array.isArray(value.customEQ) && value.customEQ.length === 10
      ? value.customEQ.map(v => clamp(v, -12, 12, 0))
      : [...bands];
    return {
      masterVolume: clamp(value.masterVolume, 0, 1, 0.9),
      uiVolume: clamp(value.uiVolume, 0, 1, 0.18),
      uiSounds: typeof value.uiSounds === 'boolean' ? value.uiSounds : true,
      introSounds: typeof value.introSounds === 'boolean' ? value.introSounds : false,
      smoothVolume: typeof value.smoothVolume === 'boolean' ? value.smoothVolume : true,
      muted: typeof value.muted === 'boolean' ? value.muted : false,
      eqEnabled: typeof value.eqEnabled === 'boolean' ? value.eqEnabled : true,
      eqBands: bands,
      eqPreset: text(value.eqPreset, 40) || 'Flat',
      customEQ
    };
  }
  function normalizeMetadata(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('В резервной копии отсутствует корректный раздел metadata.');
    const playlists = Array.isArray(value.playlists) ? value.playlists.slice(0, MAX_PLAYLISTS).flatMap(p => {
      if (!p || typeof p !== 'object' || Array.isArray(p)) return [];
      const id = text(p.id, 100), name = text(p.name, 80);
      if (!id || !name) return [];
      return [{ id, name, description: text(p.description, 500), trackIds: uniqueStrings(p.trackIds), createdAt: clamp(p.createdAt, 0, 8640000000000000, Date.now()), updatedAt: clamp(p.updatedAt, 0, 8640000000000000, Date.now()) }];
    }) : [];
    const prefs = value.prefs && typeof value.prefs === 'object' && !Array.isArray(value.prefs) ? value.prefs : {};
    return {
      favorites: uniqueStrings(value.favorites),
      history: uniqueStrings(value.history).slice(0, 1000),
      searchHistory: uniqueStrings(value.searchHistory).slice(0, 30),
      queueIds: uniqueStrings(value.queueIds),
      queueIndex: Math.floor(clamp(value.queueIndex, 0, MAX_ARRAY, 0)),
      playlists,
      prefs: {
        accent: safeAccent(prefs.accent),
        compact: typeof prefs.compact === 'boolean' ? prefs.compact : false,
        animations: typeof prefs.animations === 'boolean' ? prefs.animations : false
      },
      shuffle: typeof value.shuffle === 'boolean' ? value.shuffle : false,
      repeat: value.repeat === 'one' || value.repeat === 'all' ? value.repeat : value.repeat === true,
      volume: clamp(value.volume, 0, 1, 0.72)
    };
  }
  function normalizeBackup(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw) || raw.app !== 'QWEMU') throw new TypeError('Это не резервная копия QWEMU.');
    if (!['1.1.0', '1.2.0'].includes(String(raw.version || ''))) throw new TypeError('Версия резервной копии не поддерживается.');
    const metadata = normalizeMetadata(raw.metadata);
    const audioSettings = normalizeAudioSettings(raw.audioSettings);
    return { metadata, audioSettings, exportedAt: text(raw.exportedAt, 80), sourceVersion: String(raw.version) };
  }
  function mergeMetadata(current, incoming) {
    const a = normalizeMetadata(current || {}), b = normalizeMetadata(incoming || {});
    const mergeIds = (left, right, limit) => [...new Set([...left, ...right])].slice(0, limit);
    const playlistMap = new Map(a.playlists.map(p => [p.id, p]));
    for (const p of b.playlists) {
      const old = playlistMap.get(p.id);
      playlistMap.set(p.id, old ? { ...old, ...p, trackIds: mergeIds(old.trackIds, p.trackIds, MAX_ARRAY) } : p);
    }
    return {
      favorites: mergeIds(a.favorites, b.favorites, MAX_ARRAY),
      history: mergeIds(b.history, a.history, 1000),
      searchHistory: mergeIds(b.searchHistory, a.searchHistory, 30),
      queueIds: mergeIds(a.queueIds, b.queueIds, MAX_ARRAY),
      queueIndex: b.queueIndex,
      playlists: [...playlistMap.values()].slice(0, MAX_PLAYLISTS),
      prefs: { ...a.prefs, ...b.prefs },
      shuffle: b.shuffle,
      repeat: b.repeat,
      volume: b.volume
    };
  }
  return Object.freeze({ normalizeBackup, normalizeMetadata, normalizeAudioSettings, mergeMetadata, safeHttpUrl });
});
