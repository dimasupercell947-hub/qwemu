#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
mod api;
mod audio;

use tauri::{
    menu::{Menu, MenuItem, PredefinedMenuItem},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    AppHandle, State, WindowEvent,
};

use base64::Engine as _;
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    fs,
    io::{Read, Write},
    net::{IpAddr, SocketAddr, ToSocketAddrs},
    path::{Path, PathBuf},
    sync::Mutex,
};
use tauri::{Emitter, Manager, WebviewUrl, WebviewWindowBuilder};

fn sqlite_sidecar(path: &Path, suffix: &str) -> PathBuf {
    let mut sidecar = path.as_os_str().to_os_string();
    sidecar.push(suffix);
    PathBuf::from(sidecar)
}

fn remove_sqlite_family(path: &Path) {
    let _ = fs::remove_file(path);
    for suffix in ["-wal", "-shm", "-journal"] {
        let _ = fs::remove_file(sqlite_sidecar(path, suffix));
    }
}

/// Copy a closed SQLite database together with any WAL sidecars, validate the
/// copy, checkpoint it, and leave the source untouched.
fn copy_validated_sqlite(source: &Path, destination: &Path) -> Result<(), String> {
    if let Some(parent) = destination.parent() {
        fs::create_dir_all(parent)
            .map_err(|e| format!("Не удалось создать каталог резервной копии: {e}"))?;
    }
    remove_sqlite_family(destination);
    if let Err(error) = fs::copy(source, destination) {
        remove_sqlite_family(destination);
        return Err(format!("Не удалось скопировать SQLite-базу: {error}"));
    }
    // -shm is a rebuildable lock/index file and is deliberately not copied.
    for suffix in ["-wal", "-journal"] {
        let from = sqlite_sidecar(source, suffix);
        if from.is_file() {
            let to = sqlite_sidecar(destination, suffix);
            if let Err(error) = fs::copy(&from, &to) {
                remove_sqlite_family(destination);
                return Err(format!(
                    "Не удалось скопировать SQLite sidecar {suffix}: {error}"
                ));
            }
        }
    }

    let validation = (|| -> Result<(), String> {
        let connection = rusqlite::Connection::open(destination).map_err(|e| e.to_string())?;
        let integrity = connection
            .query_row("PRAGMA integrity_check", [], |row| row.get::<_, String>(0))
            .map_err(|e| e.to_string())?;
        if integrity != "ok" {
            return Err(format!("SQLite integrity_check вернул: {integrity}"));
        }
        connection
            .execute_batch("PRAGMA wal_checkpoint(TRUNCATE);")
            .map_err(|e| format!("Не удалось завершить WAL checkpoint: {e}"))?;
        drop(connection);
        for suffix in ["-wal", "-shm", "-journal"] {
            let _ = fs::remove_file(sqlite_sidecar(destination, suffix));
        }
        Ok(())
    })();

    if let Err(error) = validation {
        remove_sqlite_family(destination);
        return Err(error);
    }
    Ok(())
}

fn sqlite_family_modified(path: &Path) -> Option<std::time::SystemTime> {
    [
        path.to_path_buf(),
        sqlite_sidecar(path, "-wal"),
        sqlite_sidecar(path, "-journal"),
    ]
    .into_iter()
    .filter_map(|candidate| {
        fs::metadata(candidate)
            .and_then(|metadata| metadata.modified())
            .ok()
    })
    .max()
}

fn sqlite_integrity(path: &Path) -> Result<(), String> {
    let connection = rusqlite::Connection::open(path).map_err(|e| e.to_string())?;
    let integrity = connection
        .query_row("PRAGMA integrity_check", [], |row| row.get::<_, String>(0))
        .map_err(|e| e.to_string())?;
    if integrity == "ok" {
        Ok(())
    } else {
        Err(format!("SQLite integrity_check вернул: {integrity}"))
    }
}

fn migrate_legacy_database(data_dir: &Path) -> Result<String, String> {
    fs::create_dir_all(data_dir).map_err(|e| e.to_string())?;
    let destination = data_dir.join("qwemu.sqlite3");
    if destination.exists() {
        let connection = rusqlite::Connection::open(&destination)
            .map_err(|e| format!("Не удалось открыть существующую базу QWEMU: {e}"))?;
        let integrity = connection
            .query_row("PRAGMA integrity_check", [], |row| row.get::<_, String>(0))
            .map_err(|e| e.to_string())?;
        if integrity != "ok" {
            return Err(format!("Существующая база QWEMU не прошла integrity_check: {integrity}. Исходный файл не изменён."));
        }
        return Ok(
            "Основная база уже существует и прошла integrity_check; импорт не выполнялся.".into(),
        );
    }

    let mut candidates: Vec<PathBuf> = Vec::new();
    if let Ok(appdata) = std::env::var("APPDATA") {
        let root = PathBuf::from(appdata);
        for name in ["qwemu", "QWEMU", "com.qwemu.pc"] {
            candidates.push(root.join(name).join("data"));
            candidates.push(root.join(name));
        }
    }
    if let Ok(local) = std::env::var("LOCALAPPDATA") {
        for name in ["qwemu", "QWEMU", "com.qwemu.pc"] {
            candidates.push(PathBuf::from(&local).join(name).join("data"));
        }
    }
    if let Ok(home) = std::env::var("HOME") {
        candidates.push(PathBuf::from(&home).join(".config/qwemu/data"));
        candidates.push(PathBuf::from(&home).join(".local/share/com.qwemu.pc"));
    }

    for old_dir in candidates {
        let old_db = old_dir.join("qwemu.sqlite3");
        if !old_db.is_file() {
            continue;
        }

        // The old database is never moved or deleted. A validated backup is
        // created first; the new app database is copied from that snapshot.
        let backup = old_dir.join("qwemu.sqlite3.pre-rust-backup");
        let source_modified = sqlite_family_modified(&old_db);
        let backup_modified = sqlite_family_modified(&backup);
        let backup_is_fresh = backup.exists()
            && matches!((source_modified, backup_modified), (Some(source_time), Some(backup_time)) if backup_time >= source_time)
            && sqlite_integrity(&backup).is_ok();
        if !backup_is_fresh {
            let backup_staging = old_dir.join("qwemu.sqlite3.pre-rust-backup.importing");
            copy_validated_sqlite(&old_db, &backup_staging)?;
            // The original database remains untouched. Replace only the prior
            // backup after the new snapshot has passed integrity_check.
            remove_sqlite_family(&backup);
            fs::rename(&backup_staging, &backup).map_err(|e| {
                format!("Не удалось зафиксировать резервную копию старой базы: {e}")
            })?;
        }

        let staging = data_dir.join("qwemu.sqlite3.importing");
        copy_validated_sqlite(&backup, &staging)?;
        fs::rename(&staging, &destination)
            .map_err(|e| format!("Не удалось завершить импорт базы: {e}"))?;

        return Ok(format!(
            "SQLite импортирована из {}. Исходная база и проверенная резервная копия сохранены.",
            old_db.display()
        ));
    }
    Ok("Старая SQLite-база не найдена; создана новая база QWEMU.".into())
}

fn canonical_audio_path(app: &AppHandle, path: &str) -> Result<PathBuf, String> {
    let target = PathBuf::from(path)
        .canonicalize()
        .map_err(|e| format!("Аудиофайл недоступен: {e}"))?;
    if !target.is_file() {
        return Err("Указанный путь не является аудиофайлом.".into());
    }
    let data_music = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    let cache_audio = app
        .path()
        .app_cache_dir()
        .map_err(|e| e.to_string())?
        .join("audio-cache");
    fs::create_dir_all(&data_music).map_err(|e| e.to_string())?;
    fs::create_dir_all(&cache_audio).map_err(|e| e.to_string())?;
    let music_root = data_music.canonicalize().map_err(|e| e.to_string())?;
    let cache_root = cache_audio.canonicalize().map_err(|e| e.to_string())?;
    if !target.starts_with(&music_root) && !target.starts_with(&cache_root) {
        return Err("Rust-аудиодвижок может открывать только файлы медиатеки QWEMU и проверенного аудиокэша.".into());
    }
    Ok(target)
}

#[tauri::command]
fn audio_play(
    app: AppHandle,
    path: String,
    state: State<'_, audio::AudioState>,
) -> Result<audio::AudioStatus, String> {
    let target = canonical_audio_path(&app, &path)?;
    audio::play(&state, target.to_string_lossy().as_ref())
}
#[tauri::command]
fn audio_pause(state: State<'_, audio::AudioState>) -> Result<audio::AudioStatus, String> {
    audio::pause(&state)
}
#[tauri::command]
fn audio_resume(state: State<'_, audio::AudioState>) -> Result<audio::AudioStatus, String> {
    audio::resume(&state)
}
#[tauri::command]
fn audio_stop(state: State<'_, audio::AudioState>) -> Result<audio::AudioStatus, String> {
    audio::stop(&state)
}
#[tauri::command]
fn audio_seek(
    seconds: f64,
    state: State<'_, audio::AudioState>,
) -> Result<audio::AudioStatus, String> {
    audio::seek(&state, seconds)
}
#[tauri::command]
fn audio_set_volume(
    value: f32,
    state: State<'_, audio::AudioState>,
) -> Result<audio::AudioStatus, String> {
    audio::set_volume(&state, value)
}
#[tauri::command]
fn audio_set_eq(
    enabled: bool,
    bands: [f32; 10],
    state: State<'_, audio::AudioState>,
) -> Result<audio::AudioStatus, String> {
    audio::set_eq(&state, enabled, bands)
}
#[tauri::command]
fn audio_status(state: State<'_, audio::AudioState>) -> Result<audio::AudioStatus, String> {
    audio::status(&state)
}
#[tauri::command(rename_all = "camelCase")]
fn audio_set_sleep_timer(
    seconds: Option<u64>,
    state: State<'_, audio::AudioState>,
) -> Result<audio::AudioStatus, String> {
    let seconds = seconds.filter(|value| *value > 0);
    audio::set_sleep_timer(&state, seconds)
}
fn canonical_manifest_file_path(path: &Path, root: &Path) -> Result<PathBuf, String> {
    let parent = path
        .parent()
        .ok_or_else(|| "У пути файла отсутствует родительский каталог.".to_string())?;
    let file_name = path
        .file_name()
        .ok_or_else(|| "У пути файла отсутствует имя.".to_string())?;
    let canonical_parent = parent
        .canonicalize()
        .map_err(|e| format!("Каталог файла недоступен: {e}"))?;
    if !canonical_parent.starts_with(root) {
        return Err("Разрешены только пути внутри медиатеки QWEMU.".into());
    }

    let candidate = canonical_parent.join(file_name);
    if candidate.exists() {
        let canonical = candidate.canonicalize().map_err(|e| e.to_string())?;
        if !canonical.starts_with(root) || !canonical.is_file() {
            return Err("Путь не является обычным файлом внутри медиатеки QWEMU.".into());
        }
        Ok(canonical)
    } else {
        // Keep missing manifest entries removable without allowing parent traversal
        // or deleting files outside the canonical library directory.
        Ok(candidate)
    }
}

#[tauri::command]
fn delete_native_file(
    app: AppHandle,
    path: String,
    state: State<'_, audio::AudioState>,
) -> Result<(), String> {
    // Validate the canonical target before touching playback state. A rejected
    // path must not pause or stop a currently playing, unrelated composition.
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music")
        .canonicalize()
        .map_err(|e| e.to_string())?;
    let target = canonical_manifest_file_path(Path::new(&path), &root)?;
    let canonical_target = target.to_string_lossy().into_owned();
    let _library_guard = lock_native_library()?;
    let mut manifest = read_native_manifest(&root)?;
    let registered = manifest.iter().any(|track| {
        canonical_manifest_file_path(Path::new(&track.native_path), &root)
            .map(|candidate| candidate == target)
            .unwrap_or(false)
    });
    if !registered {
        return Err("Этот файл не зарегистрирован в медиатеке QWEMU и не может быть удалён через её команды.".into());
    }
    manifest.retain(|track| {
        canonical_manifest_file_path(Path::new(&track.native_path), &root)
            .map(|candidate| candidate != target)
            .unwrap_or(true)
    });
    let playing_path = audio::status(&state)?.path;
    if playing_path.as_deref() == Some(canonical_target.as_str()) {
        audio::stop(&state)?;
    }
    if target.exists() {
        fs::remove_file(&target).map_err(|e| format!("Не удалось удалить файл: {e}"))?;
    }
    write_native_manifest(&root, &manifest)
}

fn default_track_available() -> bool {
    true
}

#[derive(serde::Serialize, serde::Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ImportedTrack {
    id: String,
    name: String,
    title: String,
    artist: String,
    album: String,
    native_path: String,
    url: String,
    remote: bool,
    external_url: bool,
    added_at: u128,
    #[serde(default)]
    duration: f64,
    #[serde(default)]
    sha256: Option<String>,
    #[serde(default = "default_track_available")]
    available: bool,
}

const LEGACY_IMPORT_CHUNK_MAX: usize = 192 * 1024;
const LEGACY_IMPORT_MAX_SIZE: u64 = 8 * 1024 * 1024 * 1024;
const LEGACY_IMPORT_MAX_ACTIVE: usize = 2;
const NATIVE_AUDIO_EXTENSIONS: &[&str] = &[
    "mp3", "wav", "flac", "ogg", "oga", "m4a", "aac", "aiff", "aif",
];

struct ActiveLegacyImport {
    file: fs::File,
    staging_path: PathBuf,
    expected_size: u64,
    written: u64,
    extension: String,
    track: ImportedTrack,
}

#[derive(Default)]
struct LibraryMigrationState {
    active: Mutex<HashMap<String, ActiveLegacyImport>>,
}

fn sha256_file(path: &Path) -> Result<String, String> {
    let mut file =
        fs::File::open(path).map_err(|e| format!("Не удалось открыть файл для SHA-256: {e}"))?;
    let mut hasher = Sha256::new();
    let mut buffer = [0_u8; 1024 * 1024];
    loop {
        let count = file
            .read(&mut buffer)
            .map_err(|e| format!("Не удалось прочитать файл для SHA-256: {e}"))?;
        if count == 0 {
            break;
        }
        hasher.update(&buffer[..count]);
    }
    Ok(hex::encode(hasher.finalize()))
}

fn clean_metadata(value: String, fallback: &str, max_chars: usize) -> String {
    let cleaned = value
        .chars()
        .filter(|character| !character.is_control())
        .take(max_chars)
        .collect::<String>();
    let cleaned = cleaned.trim();
    if cleaned.is_empty() {
        fallback.to_string()
    } else {
        cleaned.to_string()
    }
}

fn safe_audio_extension(file_name: &str) -> Result<String, String> {
    let extension = Path::new(file_name)
        .extension()
        .and_then(|value| value.to_str())
        .unwrap_or("")
        .to_ascii_lowercase();
    if !NATIVE_AUDIO_EXTENSIONS.contains(&extension.as_str()) {
        return Err(format!(
            "Формат файла .{} пока не поддерживается нативным импортом.",
            if extension.is_empty() {
                "?"
            } else {
                &extension
            }
        ));
    }
    Ok(extension)
}

fn write_json_atomically(path: &Path, bytes: &[u8]) -> Result<(), String> {
    let parent = path
        .parent()
        .ok_or_else(|| "У файла отсутствует родительский каталог.".to_string())?;
    fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    let staging = path.with_extension("json.importing");
    let mut file = fs::File::create(&staging).map_err(|e| e.to_string())?;
    file.write_all(bytes).map_err(|e| {
        let _ = fs::remove_file(&staging);
        e.to_string()
    })?;
    file.sync_all().map_err(|e| {
        let _ = fs::remove_file(&staging);
        e.to_string()
    })?;
    drop(file);
    if path.exists() {
        let backup = path.with_extension("json.backup");
        let _ = fs::remove_file(&backup);
        fs::rename(path, &backup).map_err(|e| {
            let _ = fs::remove_file(&staging);
            e.to_string()
        })?;
        if let Err(error) = fs::rename(&staging, path) {
            let _ = fs::rename(&backup, path);
            let _ = fs::remove_file(&staging);
            return Err(error.to_string());
        }
        let _ = fs::remove_file(backup);
    } else {
        fs::rename(&staging, path).map_err(|e| {
            let _ = fs::remove_file(&staging);
            e.to_string()
        })?;
    }
    Ok(())
}

#[tauri::command(rename_all = "camelCase")]
fn legacy_migration_begin(
    app: AppHandle,
    state: State<'_, LibraryMigrationState>,
    track_id: String,
    file_name: String,
    title: String,
    artist: String,
    album: String,
    duration: f64,
    added_at: u128,
    size: u64,
) -> Result<String, String> {
    if track_id.trim().is_empty() || track_id.len() > 240 {
        return Err("Некорректный идентификатор старого трека.".into());
    }
    if size == 0 || size > LEGACY_IMPORT_MAX_SIZE {
        return Err("Размер файла пустой или превышает лимит миграции 8 ГБ.".into());
    }
    let safe_name = file_name
        .rsplit(|character| character == '/' || character == '\\')
        .next()
        .unwrap_or("audio");
    let safe_name = clean_metadata(safe_name.to_string(), "audio", 255);
    let extension = safe_audio_extension(&safe_name)?;
    let mut active = state
        .active
        .lock()
        .map_err(|_| "Хранилище миграции заблокировано.".to_string())?;
    if active.len() >= LEGACY_IMPORT_MAX_ACTIVE {
        return Err("Достигнут лимит одновременных переносов медиатеки. Заверши или отмени текущий перенос.".into());
    }
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    let staging_dir = root.join(".migration-staging");
    fs::create_dir_all(&staging_dir)
        .map_err(|e| format!("Не удалось создать staging-каталог: {e}"))?;
    let session_id = uuid::Uuid::new_v4().to_string();
    let staging_path = staging_dir.join(format!("{session_id}.part"));
    let file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&staging_path)
        .map_err(|e| format!("Не удалось создать временный файл миграции: {e}"))?;
    let track = ImportedTrack {
        id: track_id,
        name: safe_name,
        title: clean_metadata(title, "Без названия", 512),
        artist: clean_metadata(artist, "Неизвестный исполнитель", 512),
        album: clean_metadata(album, "Локальная библиотека QWEMU", 512),
        native_path: String::new(),
        url: String::new(),
        remote: false,
        external_url: false,
        added_at: if added_at == 0 {
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis()
        } else {
            added_at
        },
        duration: if duration.is_finite() && duration > 0.0 {
            duration
        } else {
            0.0
        },
        sha256: None,
        available: true,
    };
    active.insert(
        session_id.clone(),
        ActiveLegacyImport {
            file,
            staging_path,
            expected_size: size,
            written: 0,
            extension,
            track,
        },
    );
    Ok(session_id)
}

#[tauri::command(rename_all = "camelCase")]
fn legacy_migration_write_chunk(
    state: State<'_, LibraryMigrationState>,
    session_id: String,
    offset: u64,
    data_base64: String,
    chunk_sha256: String,
) -> Result<u64, String> {
    if data_base64.len() > 300_000 {
        return Err("Слишком большой блок миграции.".into());
    }
    let bytes = base64::engine::general_purpose::STANDARD
        .decode(data_base64.as_bytes())
        .map_err(|_| "Повреждённый Base64-блок миграции.".to_string())?;
    if bytes.is_empty() || bytes.len() > LEGACY_IMPORT_CHUNK_MAX {
        return Err("Недопустимый размер блока миграции.".into());
    }
    let actual_chunk_hash = hex::encode(Sha256::digest(&bytes));
    if !actual_chunk_hash.eq_ignore_ascii_case(&chunk_sha256) {
        return Err("SHA-256 блока не совпал; блок не записан.".into());
    }
    let mut active = state
        .active
        .lock()
        .map_err(|_| "Хранилище миграции заблокировано.".to_string())?;
    let import = active
        .get_mut(&session_id)
        .ok_or_else(|| "Сессия миграции не найдена или уже завершена.".to_string())?;
    if offset != import.written {
        return Err(format!(
            "Нарушен порядок блоков: ожидалось {}, получено {offset}.",
            import.written
        ));
    }
    if import.written.saturating_add(bytes.len() as u64) > import.expected_size {
        return Err("Передано больше данных, чем размер исходного файла.".into());
    }
    import
        .file
        .write_all(&bytes)
        .map_err(|e| format!("Ошибка записи блока медиатеки: {e}"))?;
    import.written += bytes.len() as u64;
    Ok(import.written)
}

#[tauri::command(rename_all = "camelCase")]
fn legacy_migration_finalize(
    app: AppHandle,
    state: State<'_, LibraryMigrationState>,
    session_id: String,
) -> Result<ImportedTrack, String> {
    let import = {
        let mut active = state
            .active
            .lock()
            .map_err(|_| "Хранилище миграции заблокировано.".to_string())?;
        active
            .remove(&session_id)
            .ok_or_else(|| "Сессия миграции не найдена или уже завершена.".to_string())?
    };
    let ActiveLegacyImport {
        mut file,
        staging_path,
        expected_size,
        written,
        extension,
        mut track,
    } = import;
    let cleanup_path = staging_path.clone();
    let result = (|| -> Result<ImportedTrack, String> {
        if written != expected_size {
            return Err(format!(
                "Размер не совпадает: получено {written} из {expected_size} байт."
            ));
        }
        file.flush()
            .map_err(|e| format!("Не удалось завершить запись: {e}"))?;
        file.sync_all()
            .map_err(|e| format!("Не удалось синхронизировать файл: {e}"))?;
        drop(file);

        let digest = sha256_file(&staging_path)?;
        let root = app
            .path()
            .app_data_dir()
            .map_err(|e| e.to_string())?
            .join("music");
        fs::create_dir_all(&root).map_err(|e| e.to_string())?;
        let _library_guard = lock_native_library()?;
        let mut manifest = read_native_manifest(&root)?;
        if manifest.iter().any(|item| item.id == track.id) {
            return Err("Трек с таким ID уже зарегистрирован в Rust-медиатеке; исходная IndexedDB-запись оставлена.".into());
        }

        let id = uuid::Uuid::new_v4().to_string();
        let destination = root.join(format!("{id}.{extension}"));
        fs::rename(&staging_path, &destination)
            .map_err(|e| format!("Не удалось зафиксировать нативный файл: {e}"))?;
        track.native_path = destination.to_string_lossy().into_owned();
        track.url = format!("native://{}", track.id);
        track.sha256 = Some(digest);
        track.available = true;
        manifest.push(track.clone());
        if let Err(error) = write_native_manifest(&root, &manifest) {
            let _ = fs::remove_file(&destination);
            return Err(format!(
                "Не удалось обновить каталог Rust; исходный IndexedDB Blob сохранён: {error}"
            ));
        }
        Ok(track)
    })();
    if result.is_err() {
        let _ = fs::remove_file(cleanup_path);
    }
    result
}

#[tauri::command(rename_all = "camelCase")]
fn legacy_migration_abort(
    state: State<'_, LibraryMigrationState>,
    session_id: String,
) -> Result<(), String> {
    let import = state
        .active
        .lock()
        .map_err(|_| "Хранилище миграции заблокировано.".to_string())?
        .remove(&session_id);
    if let Some(import) = import {
        let _ = fs::remove_file(import.staging_path);
    }
    Ok(())
}

#[tauri::command(rename_all = "camelCase")]
fn save_library_migration_report(app: AppHandle, report: serde_json::Value) -> Result<(), String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let bytes = serde_json::to_vec_pretty(&report).map_err(|e| e.to_string())?;
    write_json_atomically(&root.join("library-migration-report.json"), &bytes)
}

fn native_manifest_path(root: &std::path::Path) -> PathBuf {
    root.join("library.json")
}
fn native_manifest_backup_path(root: &std::path::Path) -> PathBuf {
    root.join("library.json.bak")
}

fn restore_native_manifest_backup(
    root: &std::path::Path,
    primary: &Path,
    backup: &Path,
) -> Result<Vec<ImportedTrack>, String> {
    let backup_bytes = fs::read(backup).map_err(|e| {
        format!(
            "Не удалось прочитать резервный каталог музыки {}: {e}",
            backup.display()
        )
    })?;
    let mut parsed = serde_json::from_slice::<Vec<ImportedTrack>>(&backup_bytes).map_err(|e| {
        format!("Основной каталог повреждён, а резервная копия тоже недействительна: {e}")
    })?;

    // Restore through a staging file. Preserve a corrupt primary file for diagnosis
    // and never overwrite the validated backup during recovery.
    let staging = root.join("library.json.recovery.tmp");
    let staging_result = (|| -> Result<(), String> {
        let mut staged = fs::OpenOptions::new()
            .create(true)
            .truncate(true)
            .write(true)
            .open(&staging)
            .map_err(|e| format!("Не удалось создать файл восстановления каталога: {e}"))?;
        staged
            .write_all(&backup_bytes)
            .map_err(|e| format!("Не удалось записать восстановленный каталог: {e}"))?;
        staged
            .sync_all()
            .map_err(|e| format!("Не удалось синхронизировать восстановленный каталог: {e}"))?;
        Ok(())
    })();
    if let Err(error) = staging_result {
        let _ = fs::remove_file(&staging);
        return Err(error);
    }

    let corrupt = if primary.exists() {
        let destination = root.join(format!("library.json.corrupt-{}", uuid::Uuid::new_v4()));
        if let Err(error) = fs::rename(primary, &destination) {
            let _ = fs::remove_file(&staging);
            return Err(format!(
                "Не удалось сохранить повреждённый каталог перед восстановлением: {error}"
            ));
        }
        Some(destination)
    } else {
        None
    };

    if let Err(error) = fs::rename(&staging, primary) {
        if let Some(corrupt_path) = corrupt.as_ref() {
            let _ = fs::rename(corrupt_path, primary);
        }
        let _ = fs::remove_file(&staging);
        return Err(format!(
            "Не удалось восстановить каталог медиатеки: {error}"
        ));
    }

    for track in &mut parsed {
        track.available = PathBuf::from(&track.native_path).is_file();
    }
    Ok(parsed)
}

fn read_native_manifest(root: &std::path::Path) -> Result<Vec<ImportedTrack>, String> {
    let path = native_manifest_path(root);
    let backup = native_manifest_backup_path(root);

    if !path.is_file() {
        if backup.is_file() {
            return restore_native_manifest_backup(root, &path, &backup);
        }
        return Ok(Vec::new());
    }

    let raw = fs::read(&path).map_err(|e| {
        format!(
            "Не удалось прочитать каталог музыки {}: {e}",
            path.display()
        )
    })?;
    match serde_json::from_slice::<Vec<ImportedTrack>>(&raw) {
        Ok(mut parsed) => {
            // Missing files stay in the manifest for recovery/diagnostics. Never
            // silently discard an entry just because a file is temporarily absent.
            for track in &mut parsed {
                track.available = PathBuf::from(&track.native_path).is_file();
            }
            Ok(parsed)
        }
        Err(primary_error) if backup.is_file() => {
            restore_native_manifest_backup(root, &path, &backup).map_err(|backup_error| {
                format!("Каталог музыки повреждён ({primary_error}); восстановление из резервной копии не удалось: {backup_error}")
            })
        }
        Err(error) => Err(format!("Каталог музыки повреждён; исходный файл сохранён: {error}")),
    }
}

fn write_native_manifest(root: &std::path::Path, tracks: &[ImportedTrack]) -> Result<(), String> {
    fs::create_dir_all(root).map_err(|e| e.to_string())?;
    let path = native_manifest_path(root);
    let staging = root.join("library.json.tmp");
    let bytes = serde_json::to_vec_pretty(tracks).map_err(|e| e.to_string())?;
    let mut file = fs::OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .open(&staging)
        .map_err(|e| format!("Не удалось создать staging-каталог медиатеки: {e}"))?;
    file.write_all(&bytes).map_err(|e| {
        let _ = fs::remove_file(&staging);
        e.to_string()
    })?;
    file.sync_all().map_err(|e| {
        let _ = fs::remove_file(&staging);
        e.to_string()
    })?;
    drop(file);

    let backup = native_manifest_backup_path(root);
    if path.exists() {
        // Keep one previous known-good manifest after a successful update.
        let _ = fs::remove_file(&backup);
        fs::rename(&path, &backup).map_err(|e| {
            let _ = fs::remove_file(&staging);
            e.to_string()
        })?;
    }
    if let Err(error) = fs::rename(&staging, &path) {
        if backup.exists() {
            let _ = fs::rename(&backup, &path);
        }
        let _ = fs::remove_file(&staging);
        return Err(error.to_string());
    }
    Ok(())
}

fn cleanup_abandoned_migrations(data_dir: &Path) -> Result<usize, String> {
    let staging_dir = data_dir.join("music").join(".migration-staging");
    if !staging_dir.exists() {
        return Ok(0);
    }
    let entries = fs::read_dir(&staging_dir)
        .map_err(|e| format!("Не удалось проверить временные файлы миграции: {e}"))?;
    let mut removed = 0;
    for entry in entries {
        let entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path();
        if entry.file_type().map_err(|e| e.to_string())?.is_file()
            && path.extension().and_then(|value| value.to_str()) == Some("part")
        {
            fs::remove_file(&path).map_err(|e| {
                format!(
                    "Не удалось удалить незавершённый staging-файл {}: {e}",
                    path.display()
                )
            })?;
            removed += 1;
        }
    }
    Ok(removed)
}

#[tauri::command]
fn list_native_tracks(app: AppHandle) -> Result<Vec<ImportedTrack>, String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let _library_guard = lock_native_library()?;
    let tracks = read_native_manifest(&root)?;
    write_native_manifest(&root, &tracks)?;
    Ok(tracks)
}

#[tauri::command]
fn register_native_tracks(
    app: AppHandle,
    tracks: Vec<ImportedTrack>,
) -> Result<Vec<ImportedTrack>, String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let canonical_root = root.canonicalize().map_err(|e| e.to_string())?;
    let _library_guard = lock_native_library()?;
    let mut manifest = read_native_manifest(&root)?;
    let mut known = manifest
        .iter()
        .map(|track| track.id.clone())
        .collect::<std::collections::HashSet<_>>();
    for mut track in tracks {
        if track.id.is_empty() || !known.insert(track.id.clone()) {
            continue;
        }
        let Ok(target) = PathBuf::from(&track.native_path).canonicalize() else {
            continue;
        };
        if !target.starts_with(&canonical_root) || !target.is_file() {
            continue;
        }
        track.native_path = target.to_string_lossy().into_owned();
        track.available = true;
        manifest.push(track);
    }
    write_native_manifest(&root, &manifest)?;
    Ok(manifest)
}

#[tauri::command(rename_all = "camelCase")]
fn update_native_track_metadata(
    app: AppHandle,
    track_id: String,
    title: String,
    artist: String,
    album: String,
    duration: f64,
) -> Result<ImportedTrack, String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    let canonical_root = root.canonicalize().map_err(|e| e.to_string())?;
    let _library_guard = lock_native_library()?;
    let mut manifest = read_native_manifest(&root)?;
    let track = manifest
        .iter_mut()
        .find(|item| item.id == track_id)
        .ok_or_else(|| "Нативный трек не найден в каталоге QWEMU.".to_string())?;
    let target = PathBuf::from(&track.native_path)
        .canonicalize()
        .map_err(|e| format!("Файл нативного трека недоступен: {e}"))?;
    if !target.starts_with(&canonical_root) || !target.is_file() {
        return Err("Путь нативного трека не прошёл проверку безопасности.".into());
    }
    track.title = clean_metadata(title, "Без названия", 512);
    track.artist = clean_metadata(artist, "Неизвестный исполнитель", 512);
    track.album = clean_metadata(album, "Локальная библиотека QWEMU", 512);
    if duration.is_finite() && duration > 0.0 {
        track.duration = duration;
    }
    track.available = true;
    let updated = track.clone();
    write_native_manifest(&root, &manifest)?;
    Ok(updated)
}

fn is_supported_native_extension(extension: &str) -> bool {
    matches!(
        extension.to_ascii_lowercase().as_str(),
        "mp3" | "wav" | "flac" | "ogg" | "oga" | "m4a" | "aac" | "aiff" | "aif"
    )
}

fn import_audio_sources(
    app: &AppHandle,
    files: Vec<PathBuf>,
) -> Result<Vec<ImportedTrack>, String> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let mut expanded_sources = Vec::new();
    for source in files {
        if source.is_dir() {
            collect_audio_files(&source, 0, &mut expanded_sources)?;
        } else {
            expanded_sources.push(source);
        }
        if expanded_sources.len() > 5_000 {
            return Err("В одном импорте допускается не более 5000 аудиофайлов.".into());
        }
    }
    let mut out: Vec<ImportedTrack> = Vec::new();
    let mut total_bytes = 0_u64;
    for source in expanded_sources {
        if !source.is_file() {
            continue;
        }
        let ext = source
            .extension()
            .and_then(|v| v.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        if !is_supported_native_extension(&ext) {
            continue;
        }
        let source_size = match fs::metadata(&source) {
            Ok(metadata) => metadata.len(),
            Err(error) => {
                for imported in &out {
                    let _ = fs::remove_file(&imported.native_path);
                }
                return Err(format!(
                    "Не удалось прочитать размер {}: {error}",
                    source.display()
                ));
            }
        };
        if source_size == 0 || source_size > 8 * 1024 * 1024 * 1024 {
            for imported in &out {
                let _ = fs::remove_file(&imported.native_path);
            }
            return Err(format!(
                "Файл {} пустой или превышает лимит 8 ГБ.",
                source.display()
            ));
        }
        total_bytes = total_bytes.saturating_add(source_size);
        if total_bytes > 16 * 1024 * 1024 * 1024 {
            for imported in &out {
                let _ = fs::remove_file(&imported.native_path);
            }
            return Err("Общий размер одного импорта не должен превышать 16 ГБ.".into());
        }
        let name = source
            .file_name()
            .and_then(|v| v.to_str())
            .unwrap_or("audio")
            .to_string();
        let id = uuid::Uuid::new_v4().to_string();
        let destination = root.join(format!("{id}.{ext}"));
        let copied = match fs::copy(&source, &destination) {
            Ok(value) if value == source_size => value,
            Ok(value) => {
                for imported in &out {
                    let _ = fs::remove_file(&imported.native_path);
                }
                let _ = fs::remove_file(&destination);
                return Err(format!(
                    "Размер копии {name} не совпал: {value} из {source_size} байт."
                ));
            }
            Err(error) => {
                for imported in &out {
                    let _ = fs::remove_file(&imported.native_path);
                }
                let _ = fs::remove_file(&destination);
                return Err(format!("Не удалось импортировать {name}: {error}"));
            }
        };
        let _ = copied;
        if let Err(error) = fs::OpenOptions::new()
            .read(true)
            .write(true)
            .open(&destination)
            .and_then(|file| file.sync_all())
        {
            for imported in &out {
                let _ = fs::remove_file(&imported.native_path);
            }
            let _ = fs::remove_file(&destination);
            return Err(format!(
                "Не удалось синхронизировать импортированный файл {name}: {error}"
            ));
        }
        let base = name.rsplit_once('.').map(|v| v.0).unwrap_or(&name);
        let (artist, title) = base
            .split_once(" - ")
            .map(|(a, t)| (a.to_string(), t.to_string()))
            .unwrap_or(("Неизвестный исполнитель".into(), base.to_string()));
        let digest = match sha256_file(&destination) {
            Ok(value) => Some(value),
            Err(error) => {
                for imported in &out {
                    let _ = fs::remove_file(&imported.native_path);
                }
                let _ = fs::remove_file(&destination);
                return Err(format!(
                    "Не удалось проверить импортированный файл {name}: {error}"
                ));
            }
        };
        out.push(ImportedTrack {
            id: id.clone(),
            name,
            title,
            artist,
            album: "Локальная библиотека QWEMU".into(),
            native_path: destination.to_string_lossy().into_owned(),
            url: format!("native://{id}"),
            remote: false,
            external_url: false,
            added_at: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis(),
            duration: 0.0,
            sha256: digest,
            available: true,
        });
    }
    let _library_guard = match lock_native_library() {
        Ok(guard) => guard,
        Err(error) => {
            for imported in &out {
                let _ = fs::remove_file(&imported.native_path);
            }
            return Err(error);
        }
    };
    let mut manifest = match read_native_manifest(&root) {
        Ok(items) => items,
        Err(error) => {
            for imported in &out {
                let _ = fs::remove_file(&imported.native_path);
            }
            return Err(error);
        }
    };
    manifest.extend(out.iter().cloned());
    if let Err(error) = write_native_manifest(&root, &manifest) {
        for imported in &out {
            let _ = fs::remove_file(&imported.native_path);
        }
        return Err(format!("Не удалось сохранить каталог музыки: {error}"));
    }
    Ok(out)
}

fn collect_audio_files(
    directory: &Path,
    depth: usize,
    files: &mut Vec<PathBuf>,
) -> Result<(), String> {
    if depth > 24 {
        return Err("Папка слишком глубоко вложена (лимит 24 уровня).".into());
    }
    for entry in fs::read_dir(directory)
        .map_err(|e| format!("Не удалось прочитать папку {}: {e}", directory.display()))?
    {
        let entry = entry.map_err(|e| e.to_string())?;
        let kind = entry.file_type().map_err(|e| e.to_string())?;
        let path = entry.path();
        // Do not follow symlinks: a selected folder must not import files outside it.
        if kind.is_symlink() {
            continue;
        }
        if kind.is_dir() {
            collect_audio_files(&path, depth + 1, files)?;
        } else if kind.is_file() {
            let ext = path
                .extension()
                .and_then(|value| value.to_str())
                .unwrap_or("");
            if is_supported_native_extension(ext) {
                files.push(path);
                if files.len() > 5_000 {
                    return Err("В папке найдено больше 5000 аудиофайлов. Раздели импорт на несколько папок.".into());
                }
            }
        }
    }
    Ok(())
}

#[tauri::command]
fn import_audio_files(app: AppHandle) -> Result<Vec<ImportedTrack>, String> {
    let files = rfd::FileDialog::new()
        .set_title("Добавить музыку в QWEMU")
        .add_filter(
            "Аудиофайлы",
            &[
                "mp3", "wav", "flac", "ogg", "oga", "m4a", "aac", "aiff", "aif",
            ],
        )
        .pick_files();
    let Some(files) = files else {
        return Ok(Vec::new());
    };
    import_audio_sources(&app, files)
}

#[tauri::command]
fn import_audio_folder(app: AppHandle) -> Result<Vec<ImportedTrack>, String> {
    let Some(folder) = rfd::FileDialog::new()
        .set_title("Выбрать папку с музыкой для QWEMU")
        .pick_folder()
    else {
        return Ok(Vec::new());
    };
    let mut files = Vec::new();
    collect_audio_files(&folder, 0, &mut files)?;
    import_audio_sources(&app, files)
}

const BROWSER_DOWNLOAD_MAX_BYTES: u64 = 512 * 1024 * 1024;
const BROWSER_AUDIO_EXTENSIONS: &[&str] = &[
    "mp3", "wav", "flac", "ogg", "oga", "m4a", "aac", "aiff", "aif",
];
static NATIVE_LIBRARY_LOCK: Mutex<()> = Mutex::new(());
static AUDIO_CACHE_LOCK: Mutex<()> = Mutex::new(());

fn lock_audio_cache() -> Result<std::sync::MutexGuard<'static, ()>, String> {
    AUDIO_CACHE_LOCK
        .lock()
        .map_err(|_| "Аудиокэш временно заблокирован.".to_string())
}

fn lock_native_library() -> Result<std::sync::MutexGuard<'static, ()>, String> {
    NATIVE_LIBRARY_LOCK
        .lock()
        .map_err(|_| "Операции с нативной медиатекой временно заблокированы.".to_string())
}

fn is_non_public_ip(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(value) => {
            let octets = value.octets();
            value.is_private()
                || value.is_loopback()
                || value.is_link_local()
                || value.is_unspecified()
                || value.is_broadcast()
                || value.is_multicast()
                || octets[0] == 0
                || octets[0] >= 224
                || (octets[0] == 100 && (64..=127).contains(&octets[1]))
                || (octets[0] == 192 && octets[1] == 0 && (octets[2] == 0 || octets[2] == 2))
                || (octets[0] == 198
                    && ((octets[1] == 18 || octets[1] == 19)
                        || (octets[1] == 51 && octets[2] == 100)))
                || (octets[0] == 203 && octets[1] == 0 && octets[2] == 113)
        }
        IpAddr::V6(value) => {
            value.is_loopback()
                || value.is_unique_local()
                || value.is_unicast_link_local()
                || value.is_unspecified()
                || value.is_multicast()
                || (value.segments()[0] == 0x2001 && value.segments()[1] == 0x0db8)
                || value
                    .to_ipv4_mapped()
                    .is_some_and(|mapped| is_non_public_ip(IpAddr::V4(mapped)))
        }
    }
}

fn resolve_public_addresses(parsed: &url::Url) -> Result<Vec<SocketAddr>, String> {
    let host = parsed
        .host_str()
        .ok_or_else(|| "В ссылке отсутствует адрес сайта.".to_string())?;
    let port = parsed
        .port_or_known_default()
        .ok_or_else(|| "Не удалось определить порт сайта.".to_string())?;
    let addresses = (host, port)
        .to_socket_addrs()
        .map_err(|e| format!("Не удалось определить публичный адрес сайта: {e}"))?
        .collect::<Vec<_>>();
    if addresses.is_empty()
        || addresses
            .iter()
            .any(|address| is_non_public_ip(address.ip()))
    {
        return Err("Сайт разрешается в локальный, служебный или непубличный IP-адрес. Загрузка заблокирована.".into());
    }
    Ok(addresses)
}

fn is_audio_content_type(value: &str) -> bool {
    let mime = value
        .split(';')
        .next()
        .unwrap_or("")
        .trim()
        .to_ascii_lowercase();
    mime.starts_with("audio/")
        || matches!(
            mime.as_str(),
            "application/ogg" | "application/octet-stream" | "binary/octet-stream"
        )
}

fn download_public_audio_to_file(
    parsed: &url::Url,
    staging: &Path,
    max_bytes: u64,
) -> Result<u64, String> {
    let host = parsed
        .host_str()
        .ok_or_else(|| "В ссылке отсутствует адрес сайта.".to_string())?;
    let addresses = resolve_public_addresses(parsed)?;
    let client = reqwest::blocking::Client::builder()
        .timeout(std::time::Duration::from_secs(90))
        .redirect(reqwest::redirect::Policy::none())
        .no_proxy()
        .resolve_to_addrs(host, &addresses)
        .user_agent("QWEMU-PC/1.2.0 native-audio")
        .build()
        .map_err(|e| format!("Не удалось подготовить загрузчик: {e}"))?;
    let response = client
        .get(parsed.clone())
        .send()
        .map_err(|e| format!("Ошибка загрузки аудио: {e}"))?;
    if !response.status().is_success() {
        return Err(format!("Сайт вернул HTTP {}. Авторизованные и перенаправляемые источники пока не поддерживаются.", response.status()));
    }
    if let Some(value) = response
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
    {
        if !is_audio_content_type(value) {
            return Err(format!("Источник вернул {value}, а не аудиофайл."));
        }
    }
    if let Some(length) = response.content_length() {
        if length == 0 || length > max_bytes {
            return Err("Аудиофайл пустой или превышает лимит 512 МБ.".into());
        }
    }
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(staging)
        .map_err(|e| format!("Не удалось создать временный аудиофайл: {e}"))?;
    let mut limited = response.take(max_bytes.saturating_add(1));
    let copied = match std::io::copy(&mut limited, &mut file) {
        Ok(value) => value,
        Err(error) => {
            drop(file);
            let _ = fs::remove_file(staging);
            return Err(format!("Не удалось записать аудиофайл: {error}"));
        }
    };
    if copied == 0 || copied > max_bytes {
        drop(file);
        let _ = fs::remove_file(staging);
        return Err("Аудиофайл пустой или превышает лимит 512 МБ.".into());
    }
    if let Err(error) = file.sync_all() {
        drop(file);
        let _ = fs::remove_file(staging);
        return Err(format!("Не удалось синхронизировать аудиофайл: {error}"));
    }
    Ok(copied)
}

fn validate_public_http_url(raw: &str) -> Result<url::Url, String> {
    let parsed = url::Url::parse(raw).map_err(|_| "Некорректная ссылка.".to_string())?;
    if !parsed.username().is_empty() || parsed.password().is_some() {
        return Err("Ссылки со встроенными логином или паролем не поддерживаются.".into());
    }
    if !matches!(parsed.scheme(), "http" | "https") {
        return Err("Поддерживаются только ссылки HTTP и HTTPS.".into());
    }
    let host = parsed
        .host_str()
        .ok_or_else(|| "В ссылке отсутствует адрес сайта.".to_string())?;
    let host_lower = host.to_ascii_lowercase();
    if host_lower == "localhost"
        || host_lower.ends_with(".localhost")
        || host_lower.ends_with(".local")
    {
        return Err("Локальные адреса нельзя использовать для загрузки.".into());
    }
    if let Ok(ip) = host
        .trim_matches(&['[', ']'][..])
        .parse::<std::net::IpAddr>()
    {
        let blocked = match ip {
            std::net::IpAddr::V4(v) => {
                v.is_private()
                    || v.is_loopback()
                    || v.is_link_local()
                    || v.is_unspecified()
                    || v.is_broadcast()
            }
            std::net::IpAddr::V6(v) => {
                v.is_loopback()
                    || v.is_unique_local()
                    || v.is_unicast_link_local()
                    || v.is_unspecified()
            }
        };
        if blocked {
            return Err("Загрузка с локальных и внутренних IP-адресов запрещена.".into());
        }
    }
    Ok(parsed)
}

fn audio_extension_from_url(parsed: &url::Url) -> Result<String, String> {
    let filename = parsed
        .path_segments()
        .and_then(|mut parts| parts.next_back())
        .unwrap_or("");
    safe_audio_extension(filename)
}

fn prune_audio_cache(root: &Path, keep: Option<&Path>) {
    const CACHE_LIMIT: u64 = 1024 * 1024 * 1024;
    let Ok(entries) = fs::read_dir(root) else {
        return;
    };
    let mut files = entries
        .filter_map(Result::ok)
        .filter_map(|entry| {
            let path = entry.path();
            let metadata = entry.metadata().ok()?;
            if !metadata.is_file() {
                return None;
            }
            if path.extension().and_then(|value| value.to_str()) == Some("part") {
                let _ = fs::remove_file(&path);
                return None;
            }
            Some((path, metadata.len(), metadata.modified().ok()))
        })
        .collect::<Vec<_>>();
    let mut total = files.iter().map(|(_, size, _)| *size).sum::<u64>();
    files.sort_by_key(|(_, _, modified)| *modified);
    for (path, size, _) in files {
        if total <= CACHE_LIMIT {
            break;
        }
        if keep.is_some_and(|active| active == path.as_path()) {
            continue;
        }
        if fs::remove_file(&path).is_ok() {
            total = total.saturating_sub(size);
        }
    }
}

#[tauri::command(rename_all = "camelCase")]
fn audio_play_url(
    app: AppHandle,
    address: String,
    state: State<'_, audio::AudioState>,
) -> Result<audio::AudioStatus, String> {
    let parsed = validate_public_http_url(&address)?;
    let extension = audio_extension_from_url(&parsed)?;
    let cache_root = app
        .path()
        .app_cache_dir()
        .map_err(|e| e.to_string())?
        .join("audio-cache");
    fs::create_dir_all(&cache_root).map_err(|e| e.to_string())?;
    let _cache_guard = lock_audio_cache()?;
    let cache_key = hex::encode(Sha256::digest(parsed.as_str().as_bytes()));
    let destination = cache_root.join(format!("{cache_key}.{extension}"));
    if !destination.is_file()
        || fs::metadata(&destination)
            .map(|metadata| metadata.len() == 0 || metadata.len() > BROWSER_DOWNLOAD_MAX_BYTES)
            .unwrap_or(true)
    {
        if destination.exists() {
            fs::remove_file(&destination)
                .map_err(|e| format!("Не удалось очистить повреждённый аудиокэш: {e}"))?;
        }
        let staging = cache_root.join(format!("{cache_key}.{extension}.part"));
        let _ = fs::remove_file(&staging);
        if let Err(error) =
            download_public_audio_to_file(&parsed, &staging, BROWSER_DOWNLOAD_MAX_BYTES)
        {
            let _ = fs::remove_file(&staging);
            return Err(error);
        }
        if let Err(error) = fs::rename(&staging, &destination) {
            let _ = fs::remove_file(&staging);
            return Err(format!("Не удалось зафиксировать аудиокэш: {error}"));
        }
    }
    let target = canonical_audio_path(&app, destination.to_string_lossy().as_ref())?;
    let status = audio::play(&state, target.to_string_lossy().as_ref())?;
    prune_audio_cache(&cache_root, Some(&target));
    Ok(status)
}

#[derive(serde::Serialize, serde::Deserialize, Clone)]
#[serde(rename_all = "camelCase")]
struct MusicCandidate {
    title: String,
    artist: String,
    album: String,
    duration: String,
    year: String,
    genre: String,
    page_url: String,
    audio_url: Option<String>,
    description: String,
    match_reason: String,
    confidence: u8,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct MusicSiteCheck {
    ok: bool,
    domain: String,
    status: u16,
    content_type: String,
    message: String,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct AiConfigStatus {
    configured: bool,
    model: String,
    provider: String,
    message: String,
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
struct MusicSearchResponse {
    results: Vec<MusicCandidate>,
    model: String,
    domain: String,
    search_mode: String,
    source_count: usize,
    elapsed_ms: u64,
}

fn qwemu_ai_model_name() -> String {
    std::env::var("QWEMU_AI_MODEL")
        .ok()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| "gpt-6.2-astra".into())
}

#[tauri::command]
fn qwemu_ai_config_status() -> AiConfigStatus {
    let configured = std::env::var("OPENAI_API_KEY")
        .map(|key| key.trim().len() >= 20)
        .unwrap_or(false);
    let model = qwemu_ai_model_name();
    AiConfigStatus {
        configured,
        model,
        provider: "OpenAI Responses API".into(),
        message: if configured {
            "Ключ найден в переменных среды. Сеть и доступность модели будут проверены при поиске."
                .into()
        } else {
            "Ключ OPENAI_API_KEY не найден. Настрой его в переменных среды Windows и перезапусти QWEMU.".into()
        },
    }
}

fn host_is_same_site(candidate: &url::Url, root_host: &str) -> bool {
    candidate.host_str().is_some_and(|host| {
        host.eq_ignore_ascii_case(root_host)
            || host
                .to_ascii_lowercase()
                .ends_with(&format!(".{}", root_host.to_ascii_lowercase()))
    })
}

fn checked_site_request(parsed: &url::Url) -> Result<reqwest::blocking::Response, String> {
    let host = parsed
        .host_str()
        .ok_or_else(|| "В ссылке отсутствует домен.".to_string())?;
    let addresses = resolve_public_addresses(parsed)?;
    let client = reqwest::blocking::Client::builder()
        .timeout(std::time::Duration::from_secs(18))
        .connect_timeout(std::time::Duration::from_secs(8))
        .redirect(reqwest::redirect::Policy::none())
        .no_proxy()
        .resolve_to_addrs(host, &addresses)
        .user_agent("QWEMU-Music-Finder/1.1 (+https://qwemu.local)")
        .build()
        .map_err(|e| format!("Не удалось подготовить проверку сайта: {e}"))?;
    client
        .get(parsed.clone())
        .send()
        .map_err(|e| format!("Не удалось открыть сайт: {e}"))
}

#[tauri::command(rename_all = "camelCase")]
fn qwemu_check_music_site(address: String) -> Result<MusicSiteCheck, String> {
    let parsed = validate_public_http_url(&address)?;
    let domain = parsed.host_str().unwrap_or_default().to_string();
    let response = checked_site_request(&parsed)?;
    let status = response.status();
    let content_type = response
        .headers()
        .get(reqwest::header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("unknown")
        .to_string();
    if status.is_redirection() {
        return Ok(MusicSiteCheck { ok: false, domain, status: status.as_u16(), content_type,
            message: "Сайт перенаправляет на другой адрес. Для безопасности автоматические перенаправления отключены; вставь конечную HTTPS-ссылку.".into() });
    }
    if !status.is_success() {
        return Ok(MusicSiteCheck {
            ok: false,
            domain,
            status: status.as_u16(),
            content_type,
            message: format!(
                "Сайт ответил HTTP {}. Проверь адрес или доступность страницы.",
                status.as_u16()
            ),
        });
    }
    let allowed = content_type.to_ascii_lowercase().contains("text/html")
        || content_type
            .to_ascii_lowercase()
            .contains("application/xhtml+xml");
    Ok(MusicSiteCheck {
        ok: allowed,
        domain,
        status: status.as_u16(),
        content_type,
        message: if allowed {
            "Сайт доступен. Можно запустить поиск по его домену.".into()
        } else {
            "Адрес доступен, но сервер не вернул HTML-страницу. Нужна ссылка на страницу музыкального каталога.".into()
        },
    })
}

fn response_output_text(value: &serde_json::Value) -> Option<String> {
    let output = value.get("output")?.as_array()?;
    let mut text = String::new();
    for item in output {
        if item.get("type").and_then(|v| v.as_str()) != Some("message") {
            continue;
        }
        if let Some(contents) = item.get("content").and_then(|v| v.as_array()) {
            for content in contents {
                if content.get("type").and_then(|v| v.as_str()) == Some("output_text") {
                    if let Some(part) = content.get("text").and_then(|v| v.as_str()) {
                        if !text.is_empty() {
                            text.push('\n');
                        }
                        text.push_str(part);
                    }
                }
            }
        }
    }
    if text.is_empty() {
        None
    } else {
        Some(text)
    }
}

fn response_music_sources(value: &serde_json::Value, root_host: &str) -> Vec<String> {
    let mut sources = Vec::new();
    let Some(output) = value.get("output").and_then(|v| v.as_array()) else {
        return sources;
    };
    for item in output {
        if item.get("type").and_then(|v| v.as_str()) != Some("web_search_call") {
            continue;
        }
        let Some(found) = item.pointer("/action/sources").and_then(|v| v.as_array()) else {
            continue;
        };
        for source in found {
            let Some(raw) = source.get("url").and_then(|v| v.as_str()) else {
                continue;
            };
            let Ok(parsed) = url::Url::parse(raw) else {
                continue;
            };
            if !matches!(parsed.scheme(), "http" | "https")
                || !host_is_same_site(&parsed, root_host)
            {
                continue;
            }
            let normalized = parsed.to_string();
            if !sources.iter().any(|existing| existing == &normalized) {
                sources.push(normalized);
            }
            if sources.len() >= 100 {
                return sources;
            }
        }
    }
    sources
}

fn parse_music_candidates(raw: &str, limit: usize) -> Result<Vec<MusicCandidate>, String> {
    let trimmed = raw
        .trim()
        .trim_start_matches("```json")
        .trim_start_matches("```")
        .trim_end_matches("```")
        .trim();
    let start = trimmed
        .find('{')
        .ok_or_else(|| "ИИ вернул ответ без JSON-результатов.".to_string())?;
    let end = trimmed
        .rfind('}')
        .ok_or_else(|| "Ответ ИИ обрезан: не найден конец JSON.".to_string())?;
    let json: serde_json::Value = serde_json::from_str(&trimmed[start..=end])
        .map_err(|e| format!("Не удалось разобрать ответ ИИ: {e}"))?;
    let items = json
        .get("results")
        .and_then(|v| v.as_array())
        .ok_or_else(|| "В ответе ИИ отсутствует список результатов.".to_string())?;
    let mut candidates = Vec::new();
    for item in items.iter().take(limit.min(20)) {
        let get = |key: &str| {
            item.get(key)
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .trim()
                .to_string()
        };
        let title = get("title");
        let artist = get("artist");
        let page_url = get("pageUrl");
        if title.is_empty() || artist.is_empty() || page_url.is_empty() {
            continue;
        }
        let confidence = item
            .get("confidence")
            .and_then(|v| v.as_u64())
            .unwrap_or(50)
            .min(100) as u8;
        let audio_url = item
            .get("audioUrl")
            .and_then(|v| v.as_str())
            .map(str::trim)
            .filter(|v| !v.is_empty())
            .map(str::to_string);
        candidates.push(MusicCandidate {
            title: clean_metadata(title, "Без названия", 180),
            artist: clean_metadata(artist, "Неизвестный исполнитель", 180),
            album: clean_metadata(get("album"), "Неизвестный альбом", 180),
            duration: clean_metadata(get("duration"), "—", 32),
            year: clean_metadata(get("year"), "", 12),
            genre: clean_metadata(get("genre"), "", 80),
            page_url,
            audio_url,
            description: clean_metadata(get("description"), "Найдено в источнике", 500),
            match_reason: clean_metadata(get("matchReason"), "Совпадение по запросу", 240),
            confidence,
        });
    }
    Ok(candidates)
}

#[tauri::command(rename_all = "camelCase")]
fn qwemu_ai_music_search(
    address: String,
    keywords: String,
    mode: Option<String>,
    limit: Option<u8>,
    include_remixes: Option<bool>,
    sort_by: Option<String>,
) -> Result<MusicSearchResponse, String> {
    let started = std::time::Instant::now();
    let parsed = validate_public_http_url(&address)?;
    let keywords = keywords.trim();
    if keywords.is_empty() || keywords.chars().count() > 300 {
        return Err("Введи запрос длиной от 1 до 300 символов.".into());
    }
    let host = parsed
        .host_str()
        .ok_or_else(|| "В ссылке отсутствует домен.".to_string())?
        .to_string();
    let search_mode = match mode.as_deref().unwrap_or("exact") {
        "exact" => "exact",
        "discovery" => "discovery",
        "album" => "album",
        _ => {
            return Err(
                "Неизвестный режим поиска. Выбери точный поиск, открытие или поиск по альбому."
                    .into(),
            )
        }
    }
    .to_string();
    let result_limit = limit.unwrap_or(12).clamp(3, 20) as usize;
    let include_remixes = include_remixes.unwrap_or(false);
    let sort_mode = match sort_by.as_deref().unwrap_or("confidence") {
        "confidence" => "confidence",
        "title" => "title",
        "artist" => "artist",
        _ => "confidence",
    };

    let site = checked_site_request(&parsed)?;
    if !site.status().is_success()
        || !site
            .headers()
            .get(reqwest::header::CONTENT_TYPE)
            .and_then(|v| v.to_str().ok())
            .unwrap_or("")
            .to_ascii_lowercase()
            .contains("html")
    {
        return Err(
            "Сайт не прошёл проверку доступности HTML-страницы. Исправь ссылку и повтори попытку."
                .into(),
        );
    }

    let api_key = std::env::var("OPENAI_API_KEY")
        .map_err(|_| "Не настроен OPENAI_API_KEY. Добавь ключ OpenAI в переменные среды Windows и полностью перезапусти QWEMU.".to_string())?;
    if api_key.trim().len() < 20 {
        return Err("OPENAI_API_KEY выглядит некорректно. Проверь переменную среды.".into());
    }
    let model = qwemu_ai_model_name();
    if model.len() > 80
        || !model
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '-' | '_' | '.'))
    {
        return Err("QWEMU_AI_MODEL содержит недопустимые символы. Используй только имя модели из каталога OpenAI.".into());
    }

    let mode_instructions = match search_mode.as_str() {
        "discovery" => "Ищи точные совпадения и близкие релизы: официальные версии, альтернативные версии, live и ремиксы (если они разрешены настройкой). Не выдавай просто похожие по жанру песни за совпадения.",
        "album" => "Считай запрос поиском по альбому или EP. Найди доступные треки этого релиза, если есть подтверждение на страницах выбранного сайта.",
        _ => "Ищи прежде всего точные совпадения названия и исполнителя. Не подменяй точный трек похожей песней.",
    };
    let remix_instructions = if include_remixes {
        "Включай официальные ремиксы, live-версии и альтернативные версии, отдельно обозначая тип версии."
    } else {
        "Исключай ремиксы, live-версии, каверы и альтернативные версии, если пользователь явно не запросил их."
    };
    let prompt = format!(
        "Ты — музыкальный каталог-исследователь для QWEMU. Пользователь ищет: {keywords}. Режим: {search_mode}. {mode_instructions} {remix_instructions} Ищи ТОЛЬКО на домене {host} и его поддоменах. Используй публичный web_search, а не догадки. Не обходи авторизацию, подписку, paywall, DRM, robots/anti-bot или технические ограничения. Не выдумывай метаданные, URL, длительности, лицензии или прямые аудиоссылки. Если поле не подтверждено — оставь пустым, а audioUrl сделай null. Верни только JSON-объект {{\"results\":[{{\"title\":\"...\",\"artist\":\"...\",\"album\":\"...\",\"duration\":\"...\",\"year\":\"...\",\"genre\":\"...\",\"pageUrl\":\"https://...\",\"audioUrl\":null,\"description\":\"...\",\"matchReason\":\"...\",\"confidence\":0}}]}}. pageUrl обязан указывать на реальную страницу этого сайта. audioUrl указывай только если источник явно раскрывает прямой публичный аудиофайл поддерживаемого формата (mp3,wav,flac,ogg,m4a,aac,aiff); не составляй URL самостоятельно. Максимум {result_limit} результатов. confidence — оценка соответствия 0..100, не гарантия. Учитывай достоверность источника и не включай неподтверждённые результаты. Не добавляй markdown и пояснения."
    );
    let body = serde_json::json!({
        "model": model.clone(),
        "store": false,
        "max_output_tokens": 6000,
        "tools": [{
            "type": "web_search",
            "search_context_size": "medium",
            "filters": { "allowed_domains": [host] }
        }],
        "tool_choice": "required",
        "include": ["web_search_call.action.sources"],
        "input": prompt
    });
    let client = reqwest::blocking::Client::builder()
        .timeout(std::time::Duration::from_secs(120))
        .connect_timeout(std::time::Duration::from_secs(15))
        .build()
        .map_err(|e| format!("Не удалось создать AI-клиент: {e}"))?;
    let response = client
        .post("https://api.openai.com/v1/responses")
        .bearer_auth(api_key.trim())
        .json(&body)
        .send()
        .map_err(|e| format!("Не удалось связаться с облачным ИИ: {e}"))?;
    let status = response.status();
    if let Some(length) = response.content_length() {
        if length > 3 * 1024 * 1024 {
            return Err("Ответ OpenAI превысил допустимый размер 3 МБ. Сократи количество результатов и повтори поиск.".into());
        }
    }
    let mut limited = response.take(3 * 1024 * 1024 + 1);
    let mut response_bytes = Vec::new();
    limited
        .read_to_end(&mut response_bytes)
        .map_err(|e| format!("Не удалось прочитать ответ ИИ: {e}"))?;
    if response_bytes.len() > 3 * 1024 * 1024 {
        return Err("Ответ OpenAI превысил допустимый размер 3 МБ. Повтори поиск с меньшим количеством результатов.".into());
    }
    let response_text = String::from_utf8(response_bytes)
        .map_err(|_| "OpenAI вернул ответ в неподдерживаемой кодировке.".to_string())?;
    if !status.is_success() {
        let detail = serde_json::from_str::<serde_json::Value>(&response_text)
            .ok()
            .and_then(|v| {
                v.pointer("/error/message")
                    .and_then(|x| x.as_str())
                    .map(str::to_string)
            })
            .unwrap_or_else(|| format!("HTTP {}", status.as_u16()));
        let detail: String = detail.chars().take(500).collect();
        let hint = match status.as_u16() {
            401 => " Проверь API-ключ.",
            403 => " Проверь доступ ключа к выбранной модели и инструменту Web Search.",
            404 => " Проверь идентификатор модели в QWEMU_AI_MODEL.",
            429 => " Проверь лимиты запросов и доступный баланс API.",
            500..=599 => " Попробуй повторить запрос позднее.",
            _ => "",
        };
        return Err(format!(
            "Ошибка OpenAI API (HTTP {}): {}{}",
            status.as_u16(),
            detail,
            hint
        ));
    }
    let response_json: serde_json::Value = serde_json::from_str(&response_text)
        .map_err(|e| format!("OpenAI вернул некорректный JSON-ответ: {e}"))?;
    if response_json
        .get("status")
        .and_then(|v| v.as_str())
        .is_some_and(|value| value != "completed")
    {
        let reason = response_json
            .pointer("/incomplete_details/reason")
            .and_then(|v| v.as_str())
            .unwrap_or("неизвестная причина");
        return Err(format!("Облачный поиск не завершился: {reason}. Уменьши количество результатов и повтори попытку."));
    }
    let output = response_output_text(&response_json).ok_or_else(|| {
        "ИИ не вернул текстовый список результатов. Возможно, запрос был отклонён или прерван."
            .to_string()
    })?;
    let mut candidates = parse_music_candidates(&output, result_limit)?;
    candidates.retain(|candidate| {
        let Ok(page) = url::Url::parse(&candidate.page_url) else {
            return false;
        };
        matches!(page.scheme(), "http" | "https") && host_is_same_site(&page, &host)
    });
    for candidate in &mut candidates {
        if let Some(audio) = candidate.audio_url.as_ref() {
            let valid = url::Url::parse(audio).ok().filter(|url| {
                matches!(url.scheme(), "http" | "https")
                    && host_is_same_site(url, &host)
                    && audio_extension_from_url(url).is_ok()
            });
            candidate.audio_url = valid.map(|url| url.to_string());
        }
    }
    candidates.sort_by(|a, b| match sort_mode {
        "title" => a.title.to_lowercase().cmp(&b.title.to_lowercase()),
        "artist" => a.artist.to_lowercase().cmp(&b.artist.to_lowercase()),
        _ => b.confidence.cmp(&a.confidence),
    });
    let mut seen = std::collections::HashSet::new();
    candidates.retain(|item| {
        seen.insert(format!(
            "{}::{}::{}",
            item.title.to_lowercase(),
            item.artist.to_lowercase(),
            item.album.to_lowercase()
        ))
    });
    candidates.truncate(result_limit);
    let source_count = response_music_sources(&response_json, &host).len();
    Ok(MusicSearchResponse {
        results: candidates,
        model,
        domain: host,
        search_mode,
        source_count,
        elapsed_ms: started.elapsed().as_millis().min(u64::MAX as u128) as u64,
    })
}

#[tauri::command(rename_all = "camelCase")]
fn open_qwemu_browser(app: AppHandle, address: String) -> Result<(), String> {
    let parsed = validate_public_http_url(&address)?;
    if let Some(window) = app.get_webview_window("qwemu-browser") {
        window
            .navigate(parsed)
            .map_err(|e| format!("Не удалось открыть страницу: {e}"))?;
        let _ = window.set_focus();
        return Ok(());
    }
    let browser_app = app.clone();
    WebviewWindowBuilder::new(&app, "qwemu-browser", WebviewUrl::External(parsed))
        .title("Браузер QWEMU")
        .inner_size(1280.0, 820.0)
        .min_inner_size(800.0, 560.0)
        .on_download(move |_webview, event| match event {
            tauri::webview::DownloadEvent::Requested { url, destination } => {
                let ext = url
                    .path_segments()
                    .and_then(|mut parts| parts.next_back())
                    .and_then(|name| Path::new(name).extension())
                    .and_then(|value| value.to_str())
                    .unwrap_or("")
                    .to_ascii_lowercase();
                if BROWSER_AUDIO_EXTENSIONS.contains(&ext.as_str()) {
                    if let Ok(root) = browser_app.path().app_data_dir() {
                        let staging = root.join("music").join(".browser-downloads");
                        if fs::create_dir_all(&staging).is_ok() {
                            *destination =
                                staging.join(format!("{}.{}", uuid::Uuid::new_v4(), ext));
                        }
                    }
                }
                true
            }
            tauri::webview::DownloadEvent::Finished { url, path, success } => {
                if !success {
                    return true;
                }
                if let Some(downloaded) = path {
                    let ext = url
                        .path_segments()
                        .and_then(|mut parts| parts.next_back())
                        .and_then(|name| Path::new(name).extension())
                        .and_then(|value| value.to_str())
                        .unwrap_or("")
                        .to_ascii_lowercase();
                    if BROWSER_AUDIO_EXTENSIONS.contains(&ext.as_str()) {
                        if validate_public_http_url(url.as_str()).is_ok() {
                            let app_handle = browser_app.clone();
                            let source = url.to_string();
                            std::thread::spawn(move || {
                                if let Err(error) = finalize_browser_download(
                                    &app_handle,
                                    &downloaded,
                                    &ext,
                                    &source,
                                ) {
                                    eprintln!("QWEMU browser download import failed: {error}");
                                    let _ = fs::remove_file(&downloaded);
                                }
                            });
                        } else {
                            let _ = fs::remove_file(&downloaded);
                        }
                    }
                }
                true
            }
            _ => true,
        })
        .build()
        .map(|_| ())
        .map_err(|e| format!("Не удалось создать браузер QWEMU: {e}"))
}

fn finalize_browser_download(
    app: &AppHandle,
    downloaded: &Path,
    ext: &str,
    source_url: &str,
) -> Result<(), String> {
    let metadata = fs::metadata(downloaded)
        .map_err(|e| format!("Не удалось проверить скачанный файл: {e}"))?;
    if metadata.len() == 0 || metadata.len() > BROWSER_DOWNLOAD_MAX_BYTES {
        let _ = fs::remove_file(downloaded);
        return Err("Скачанный файл пустой или превышает лимит 512 МБ.".into());
    }
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let id = uuid::Uuid::new_v4().to_string();
    let destination = root.join(format!("{id}.{ext}"));
    let digest = sha256_file(downloaded)?;
    fs::rename(downloaded, &destination)
        .map_err(|e| format!("Не удалось переместить скачанный трек в медиатеку: {e}"))?;
    let filename = url::Url::parse(source_url)
        .ok()
        .and_then(|u| {
            u.path_segments()
                .and_then(|mut p| p.next_back().map(str::to_string))
        })
        .unwrap_or_else(|| format!("download.{ext}"));
    let title = filename
        .rsplit_once('.')
        .map(|v| v.0)
        .unwrap_or(&filename)
        .to_string();
    let track = ImportedTrack {
        id: id.clone(),
        name: clean_metadata(filename, "audio", 180),
        title: clean_metadata(title, "Без названия", 100),
        artist: "Неизвестный исполнитель".into(),
        album: "Загружено из браузера QWEMU".into(),
        native_path: destination.to_string_lossy().into_owned(),
        url: format!("native://{id}"),
        remote: false,
        external_url: false,
        added_at: std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis(),
        duration: 0.0,
        sha256: Some(digest),
        available: true,
    };
    let _library_guard = match lock_native_library() {
        Ok(guard) => guard,
        Err(error) => {
            let _ = fs::remove_file(&destination);
            return Err(error);
        }
    };
    let mut manifest = match read_native_manifest(&root) {
        Ok(items) => items,
        Err(error) => {
            let _ = fs::remove_file(&destination);
            return Err(error);
        }
    };
    manifest.push(track.clone());
    if let Err(error) = write_native_manifest(&root, &manifest) {
        let _ = fs::remove_file(&destination);
        return Err(error);
    }
    let _ = app.emit("qwemu://track-imported", track);
    Ok(())
}

#[tauri::command(rename_all = "camelCase")]
fn download_audio_from_url(
    app: AppHandle,
    address: String,
    suggested_title: Option<String>,
    suggested_artist: Option<String>,
) -> Result<ImportedTrack, String> {
    let parsed = validate_public_http_url(&address)?;
    let ext = audio_extension_from_url(&parsed)?;
    let root = app
        .path()
        .app_data_dir()
        .map_err(|e| e.to_string())?
        .join("music");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let id = uuid::Uuid::new_v4().to_string();
    let name = parsed
        .path_segments()
        .and_then(|mut parts| parts.next_back())
        .filter(|value| !value.is_empty())
        .unwrap_or("audio");
    let clean_name = clean_metadata(name.to_string(), "audio", 180);
    let title = suggested_title
        .filter(|value| !value.trim().is_empty())
        .map(|value| clean_metadata(value, "Без названия", 100))
        .unwrap_or_else(|| {
            clean_name
                .rsplit_once('.')
                .map(|value| value.0)
                .unwrap_or(&clean_name)
                .to_string()
        });
    let artist = suggested_artist
        .filter(|value| !value.trim().is_empty())
        .map(|value| clean_metadata(value, "Неизвестный исполнитель", 100))
        .unwrap_or_else(|| "Неизвестный исполнитель".into());
    let destination = root.join(format!("{id}.{ext}"));
    let staging = root.join(format!("{id}.{ext}.part"));
    if let Err(error) = download_public_audio_to_file(&parsed, &staging, BROWSER_DOWNLOAD_MAX_BYTES)
    {
        let _ = fs::remove_file(&staging);
        return Err(error);
    }
    let digest = match sha256_file(&staging) {
        Ok(value) => value,
        Err(error) => {
            let _ = fs::remove_file(&staging);
            return Err(error);
        }
    };
    if let Err(error) = fs::rename(&staging, &destination) {
        let _ = fs::remove_file(&staging);
        return Err(format!("Не удалось завершить загрузку: {error}"));
    }
    let track = ImportedTrack {
        id: id.clone(),
        name: clean_name,
        title,
        artist,
        album: "Загружено по ссылке в QWEMU".into(),
        native_path: destination.to_string_lossy().into_owned(),
        url: format!("native://{id}"),
        remote: false,
        external_url: false,
        added_at: std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis(),
        duration: 0.0,
        sha256: Some(digest),
        available: true,
    };
    let _library_guard = match lock_native_library() {
        Ok(guard) => guard,
        Err(error) => {
            let _ = fs::remove_file(&destination);
            return Err(error);
        }
    };
    let mut manifest = match read_native_manifest(&root) {
        Ok(items) => items,
        Err(error) => {
            let _ = fs::remove_file(&destination);
            return Err(error);
        }
    };
    manifest.push(track.clone());
    if let Err(error) = write_native_manifest(&root, &manifest) {
        let _ = fs::remove_file(&destination);
        return Err(format!(
            "Файл сохранён, но не зарегистрирован в каталоге: {error}"
        ));
    }
    let _ = app.emit("qwemu://track-imported", track.clone());
    Ok(track)
}

fn main() {
    tauri::Builder::default()
        .manage(audio::AudioState::new())
        .manage(LibraryMigrationState::default())
        .invoke_handler(tauri::generate_handler![
            audio_play,
            audio_play_url,
            audio_pause,
            audio_resume,
            audio_stop,
            audio_seek,
            audio_set_volume,
            audio_set_eq,
            audio_status,
            audio_set_sleep_timer,
            import_audio_files,
            import_audio_folder,
            list_native_tracks,
            register_native_tracks,
            delete_native_file,
            legacy_migration_begin,
            legacy_migration_write_chunk,
            legacy_migration_finalize,
            legacy_migration_abort,
            save_library_migration_report,
            update_native_track_metadata,
            open_qwemu_browser,
            download_audio_from_url,
            qwemu_check_music_site,
            qwemu_ai_config_status,
            qwemu_ai_music_search
        ])
        .on_window_event(|window, event| {
            if window.label() == "main" {
                match event {
                    WindowEvent::CloseRequested { api, .. } => {
                        // Keep the Rust audio worker alive when the user closes the
                        // window. The tray menu provides an explicit Exit action.
                        api.prevent_close();
                        let _ = window.hide();
                    }
                    WindowEvent::DragDrop(tauri::DragDropEvent::Drop { paths, .. }) => {
                        let app = window.app_handle().clone();
                        let sources = paths.to_vec();
                        std::thread::spawn(move || match import_audio_sources(&app, sources) {
                            Ok(tracks) => {
                                let _ = app.emit("qwemu://tracks-imported", tracks);
                            }
                            Err(error) => {
                                let _ = app.emit("qwemu://import-error", error);
                            }
                        });
                    }
                    _ => {}
                }
            }
        })
        .setup(|app| {
            let data_dir = app
                .path()
                .app_data_dir()
                .map_err(|e| std::io::Error::other(e.to_string()))?;
            let migration_note =
                migrate_legacy_database(&data_dir).map_err(std::io::Error::other)?;
            let abandoned =
                cleanup_abandoned_migrations(&data_dir).map_err(std::io::Error::other)?;
            if abandoned > 0 {
                println!("QWEMU: removed {abandoned} abandoned migration staging file(s).");
            }
            let resource_dir = app
                .path()
                .resource_dir()
                .map_err(|e| std::io::Error::other(e.to_string()))?;
            let mut assets_dir = resource_dir.clone();
            if !assets_dir.join("index.html").exists() {
                if let Ok(exe) = std::env::current_exe() {
                    if let Some(parent) = exe.parent() {
                        if parent.join("index.html").exists() {
                            assets_dir = parent.to_path_buf();
                        }
                    }
                }
                if !assets_dir.join("index.html").exists() {
                    if let Ok(cwd) = std::env::current_dir() {
                        if cwd.join("index.html").exists() {
                            assets_dir = cwd;
                        }
                    }
                }
            }
            api::start(api::ApiConfig {
                data_dir,
                assets_dir,
            })
            .map_err(std::io::Error::other)?;
            println!("QWEMU Rust API ready. {migration_note}");
            let url = "http://127.0.0.1:8765/".parse().unwrap();
            let window = WebviewWindowBuilder::new(app, "main", WebviewUrl::External(url))
                .title("QWEMU MUSIC 1.2.0 — Native Rust Playback")
                .inner_size(1440.0, 920.0)
                .min_inner_size(980.0, 650.0)
                .visible(true)
                .build()?;
            let _ = window;

            let show_item = MenuItem::with_id(app, "show", "Показать QWEMU", true, None::<&str>)?;
            let previous_item =
                MenuItem::with_id(app, "previous", "Предыдущая композиция", true, None::<&str>)?;
            let play_pause_item = MenuItem::with_id(
                app,
                "toggle-play",
                "Воспроизведение / пауза",
                true,
                None::<&str>,
            )?;
            let next_item =
                MenuItem::with_id(app, "next", "Следующая композиция", true, None::<&str>)?;
            let hide_item = MenuItem::with_id(app, "hide", "Скрыть окно", true, None::<&str>)?;
            let separator = PredefinedMenuItem::separator(app)?;
            let quit_item = MenuItem::with_id(app, "quit", "Выход из QWEMU", true, None::<&str>)?;
            let menu = Menu::with_items(
                app,
                &[
                    &show_item,
                    &previous_item,
                    &play_pause_item,
                    &next_item,
                    &hide_item,
                    &separator,
                    &quit_item,
                ],
            )?;
            let icon = app
                .default_window_icon()
                .cloned()
                .ok_or_else(|| std::io::Error::other("Не найдена иконка системного трея QWEMU"))?;

            TrayIconBuilder::new()
                .icon(icon)
                .menu(&menu)
                .show_menu_on_left_click(false)
                .on_menu_event(|app, event| match event.id.as_ref() {
                    "previous" => {
                        let _ = app.emit("qwemu://media-command", "previous");
                    }
                    "toggle-play" => {
                        let _ = app.emit("qwemu://media-command", "toggle-play");
                    }
                    "next" => {
                        let _ = app.emit("qwemu://media-command", "next");
                    }
                    "show" => {
                        if let Some(window) = app.get_webview_window("main") {
                            let _ = window.unminimize();
                            let _ = window.show();
                            let _ = window.set_focus();
                        }
                    }
                    "hide" => {
                        if let Some(window) = app.get_webview_window("main") {
                            let _ = window.hide();
                        }
                    }
                    "quit" => app.exit(0),
                    _ => {}
                })
                .on_tray_icon_event(|tray, event| {
                    if let TrayIconEvent::Click {
                        button: MouseButton::Left,
                        button_state: MouseButtonState::Up,
                        ..
                    } = event
                    {
                        let app = tray.app_handle();
                        if let Some(window) = app.get_webview_window("main") {
                            let _ = window.unminimize();
                            let _ = window.show();
                            let _ = window.set_focus();
                        }
                    }
                })
                .build(app)?;
            Ok(())
        })
        .build(tauri::generate_context!())
        .expect("ошибка запуска QWEMU")
        .run(|_app, _event| {});
}

#[cfg(test)]
mod migration_tests {
    use super::*;

    #[test]
    fn browser_url_validation_rejects_non_http_and_local_hosts() {
        assert!(validate_public_http_url("file:///C:/music/test.mp3").is_err());
        assert!(validate_public_http_url("http://localhost/test.mp3").is_err());
        assert!(validate_public_http_url("http://127.0.0.1/test.mp3").is_err());
        assert!(validate_public_http_url("http://[::1]/test.mp3").is_err());
        assert!(validate_public_http_url("https://user:password@example.com/music.mp3").is_err());
        assert!(validate_public_http_url("https://example.com/music.mp3").is_ok());
    }

    #[test]
    fn sqlite_copy_is_integrity_checked_and_keeps_source() {
        let root =
            std::env::temp_dir().join(format!("qwemu-migration-test-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let source = root.join("legacy.sqlite3");
        let destination = root.join("new.sqlite3");
        {
            let connection = rusqlite::Connection::open(&source).unwrap();
            connection.execute_batch("PRAGMA journal_mode=WAL; PRAGMA wal_autocheckpoint=0; CREATE TABLE sample (id INTEGER PRIMARY KEY, value TEXT NOT NULL); INSERT INTO sample(value) VALUES ('preserved');").unwrap();
            assert_eq!(
                connection
                    .query_row("SELECT value FROM sample WHERE id=1", [], |row| row
                        .get::<_, String>(0))
                    .unwrap(),
                "preserved"
            );
            copy_validated_sqlite(&source, &destination).unwrap();
            assert!(source.is_file());
            assert_eq!(
                connection
                    .query_row("SELECT value FROM sample WHERE id=1", [], |row| row
                        .get::<_, String>(0))
                    .unwrap(),
                "preserved"
            );
        }
        let imported = rusqlite::Connection::open(&destination).unwrap();
        assert_eq!(
            imported
                .query_row("SELECT value FROM sample WHERE id=1", [], |row| row
                    .get::<_, String>(0))
                .unwrap(),
            "preserved"
        );
        assert_eq!(
            imported
                .query_row("PRAGMA integrity_check", [], |row| row.get::<_, String>(0))
                .unwrap(),
            "ok"
        );
        drop(imported);
        fs::remove_dir_all(root).unwrap();
    }

    fn sample_track(id: &str, native_path: &Path) -> ImportedTrack {
        ImportedTrack {
            id: id.into(),
            name: "sample.wav".into(),
            title: "Sample".into(),
            artist: "Artist".into(),
            album: "Album".into(),
            native_path: native_path.to_string_lossy().into_owned(),
            url: format!("native://{id}"),
            remote: false,
            external_url: false,
            added_at: 1,
            duration: 1.0,
            sha256: None,
            available: true,
        }
    }

    #[test]
    fn manifest_preserves_missing_file_entries() {
        let root =
            std::env::temp_dir().join(format!("qwemu-manifest-missing-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let missing = root.join("missing.mp3");
        write_native_manifest(&root, &[sample_track("missing-track", &missing)]).unwrap();
        let loaded = read_native_manifest(&root).unwrap();
        assert_eq!(loaded.len(), 1);
        assert!(!loaded[0].available);
        write_native_manifest(&root, &loaded).unwrap();
        let saved: Vec<ImportedTrack> =
            serde_json::from_slice(&fs::read(native_manifest_path(&root)).unwrap()).unwrap();
        assert_eq!(saved.len(), 1);
        assert!(!saved[0].available);
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn manifest_keeps_previous_backup_and_can_read_it() {
        let root =
            std::env::temp_dir().join(format!("qwemu-manifest-backup-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let file = root.join("track.wav");
        fs::write(&file, b"audio").unwrap();
        write_native_manifest(&root, &[sample_track("first", &file)]).unwrap();
        write_native_manifest(&root, &[sample_track("second", &file)]).unwrap();
        let backup = native_manifest_backup_path(&root);
        assert!(backup.is_file());
        let previous: Vec<ImportedTrack> =
            serde_json::from_slice(&fs::read(&backup).unwrap()).unwrap();
        assert_eq!(previous[0].id, "first");
        fs::remove_file(native_manifest_path(&root)).unwrap();
        let recovered = read_native_manifest(&root).unwrap();
        assert_eq!(recovered[0].id, "first");
        assert!(
            native_manifest_path(&root).is_file(),
            "backup recovery should restore the primary manifest"
        );
        assert!(
            backup.is_file(),
            "backup must remain available after recovery"
        );
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn missing_manifest_file_path_is_resolvable_but_escape_paths_are_rejected() {
        let root =
            std::env::temp_dir().join(format!("qwemu-manifest-path-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let library = root.join("music");
        fs::create_dir_all(&library).unwrap();
        let canonical_root = library.canonicalize().unwrap();
        let missing = canonical_root.join("missing-track.mp3");
        let resolved = canonical_manifest_file_path(&missing, &canonical_root).unwrap();
        assert_eq!(resolved, missing);
        let outside = root.join("outside.mp3");
        assert!(canonical_manifest_file_path(&outside, &canonical_root).is_err());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn manifest_recovers_from_corrupt_primary_without_overwriting_backup() {
        let root =
            std::env::temp_dir().join(format!("qwemu-manifest-corrupt-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let file = root.join("track.wav");
        fs::write(&file, b"audio").unwrap();
        write_native_manifest(&root, &[sample_track("known-good", &file)]).unwrap();
        let backup = native_manifest_backup_path(&root);
        fs::copy(native_manifest_path(&root), &backup).unwrap();
        fs::write(native_manifest_path(&root), b"{ damaged json").unwrap();

        let recovered = read_native_manifest(&root).unwrap();
        assert_eq!(recovered.len(), 1);
        assert_eq!(recovered[0].id, "known-good");
        let restored: Vec<ImportedTrack> =
            serde_json::from_slice(&fs::read(native_manifest_path(&root)).unwrap()).unwrap();
        let saved_backup: Vec<ImportedTrack> =
            serde_json::from_slice(&fs::read(&backup).unwrap()).unwrap();
        assert_eq!(restored[0].id, "known-good");
        assert_eq!(saved_backup[0].id, "known-good");
        assert!(fs::read_dir(&root).unwrap().any(|entry| entry
            .unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with("library.json.corrupt-")));
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn safe_audio_extension_rejects_non_native_formats() {
        assert_eq!(safe_audio_extension("track.FLAC").unwrap(), "flac");
        assert!(safe_audio_extension("track.webm").is_err());
        assert!(safe_audio_extension("track.exe").is_err());
    }

    #[test]
    fn abandoned_migration_cleanup_only_removes_part_files() {
        let root =
            std::env::temp_dir().join(format!("qwemu-staging-cleanup-{}", uuid::Uuid::new_v4()));
        let staging = root.join("music").join(".migration-staging");
        fs::create_dir_all(&staging).unwrap();
        fs::write(staging.join("abandoned.part"), b"partial").unwrap();
        fs::write(staging.join("keep.txt"), b"diagnostic").unwrap();
        assert_eq!(cleanup_abandoned_migrations(&root).unwrap(), 1);
        assert!(!staging.join("abandoned.part").exists());
        assert!(staging.join("keep.txt").exists());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn sha256_file_returns_expected_digest() {
        let root = std::env::temp_dir().join(format!("qwemu-sha-test-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let file = root.join("sample.bin");
        fs::write(&file, b"abc").unwrap();
        assert_eq!(
            sha256_file(&file).unwrap(),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        fs::remove_dir_all(root).unwrap();
    }
}

#[cfg(test)]
mod native_download_tests {
    use super::*;

    #[test]
    fn non_public_ip_ranges_are_blocked() {
        for value in [
            "127.0.0.1",
            "10.1.2.3",
            "192.168.1.10",
            "169.254.2.3",
            "100.64.0.1",
            "224.0.0.1",
            "::1",
            "fc00::1",
            "fe80::1",
            "::ffff:127.0.0.1",
            "2001:db8::1",
        ] {
            let ip = value.parse::<IpAddr>().unwrap();
            assert!(is_non_public_ip(ip), "{value} must be blocked");
        }
        for value in ["8.8.8.8", "1.1.1.1", "2606:4700:4700::1111"] {
            let ip = value.parse::<IpAddr>().unwrap();
            assert!(!is_non_public_ip(ip), "{value} must be allowed");
        }
    }

    #[test]
    fn audio_content_types_reject_html_and_json() {
        assert!(is_audio_content_type("audio/mpeg"));
        assert!(is_audio_content_type("application/ogg"));
        assert!(is_audio_content_type("application/octet-stream"));
        assert!(!is_audio_content_type("text/html; charset=utf-8"));
        assert!(!is_audio_content_type("application/json"));
    }

    #[test]
    fn audio_extension_is_required_and_bounded_to_supported_types() {
        assert_eq!(safe_audio_extension("track.MP3").unwrap(), "mp3");
        assert!(safe_audio_extension("page.html").is_err());
        assert!(safe_audio_extension("track").is_err());
    }
}
