//! Native audio output and 10-band equalizer for QWEMU.
//!
//! Rodio's OutputStream is owned by a dedicated worker thread because some
//! platform backends (notably Windows) do not make it Send. Tauri state stores
//! only a command sender. The EQ source runs inside Rodio's native playback
//! pipeline; Web Audio is not used for native-file music playback.

use rodio::{Decoder, OutputStream, OutputStreamHandle, Sink, Source};
use std::{
    f32::consts::PI,
    fs::File,
    io::BufReader,
    path::Path,
    sync::{
        atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering},
        mpsc::{self, Sender},
        Arc,
    },
    thread,
    time::{Duration, Instant},
};

const EQ_FREQUENCIES: [f32; 10] = [
    60.0, 120.0, 250.0, 500.0, 1_000.0, 2_000.0, 4_000.0, 8_000.0, 12_000.0, 16_000.0,
];
const EQ_REFRESH_SAMPLES: usize = 256;

struct Playback {
    sink: Sink,
    path: String,
    duration: Option<f64>,
}

#[derive(serde::Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct AudioStatus {
    pub playing: bool,
    pub paused: bool,
    pub ended: bool,
    pub path: Option<String>,
    pub position: f64,
    pub duration: Option<f64>,
    pub volume: f32,
    pub sleep_timer_remaining_seconds: Option<u64>,
}

enum Command {
    Play(String, Sender<Result<AudioStatus, String>>),
    Pause(Sender<Result<AudioStatus, String>>),
    Resume(Sender<Result<AudioStatus, String>>),
    Stop(Sender<Result<AudioStatus, String>>),
    Seek(f64, Sender<Result<AudioStatus, String>>),
    SetVolume(f32, Sender<Result<AudioStatus, String>>),
    SetEq(bool, [f32; 10], Sender<Result<AudioStatus, String>>),
    SetSleepTimer(Option<u64>, Sender<Result<AudioStatus, String>>),
    Status(Sender<Result<AudioStatus, String>>),
}

/// Tauri state intentionally contains no Rodio handles.
pub struct AudioState {
    tx: Sender<Command>,
}

impl AudioState {
    pub fn new() -> Self {
        let (tx, rx) = mpsc::channel::<Command>();
        let eq = Arc::new(EqShared::new());
        thread::Builder::new()
            .name("qwemu-audio-engine".into())
            .spawn(move || audio_worker(rx, eq))
            .expect("Не удалось запустить аудиопоток QWEMU");
        Self { tx }
    }

    fn request(
        &self,
        make: impl FnOnce(Sender<Result<AudioStatus, String>>) -> Command,
    ) -> Result<AudioStatus, String> {
        let (reply_tx, reply_rx) = mpsc::channel();
        self.tx
            .send(make(reply_tx))
            .map_err(|_| "Аудиопоток QWEMU завершился.".to_string())?;
        reply_rx
            .recv()
            .map_err(|_| "Аудиопоток QWEMU не вернул ответ.".to_string())?
    }
}

#[derive(Default, Clone, Copy)]
struct FilterState {
    z1: f32,
    z2: f32,
}

#[derive(Clone, Copy)]
struct BiquadCoefficients {
    b0: f32,
    b1: f32,
    b2: f32,
    a1: f32,
    a2: f32,
}

impl BiquadCoefficients {
    const IDENTITY: Self = Self {
        b0: 1.0,
        b1: 0.0,
        b2: 0.0,
        a1: 0.0,
        a2: 0.0,
    };
}

struct BiquadBand {
    coefficients: BiquadCoefficients,
    states: Vec<FilterState>,
}

/// Settings are changed on the control thread and read atomically by the
/// native audio callback path. A version counter makes a complete EQ update
/// visible without taking a mutex for every audio sample.
struct EqShared {
    enabled: AtomicBool,
    gains: [AtomicU32; 10],
    version: AtomicU64,
}

impl EqShared {
    fn new() -> Self {
        Self {
            enabled: AtomicBool::new(false),
            gains: std::array::from_fn(|_| AtomicU32::new(0.0_f32.to_bits())),
            version: AtomicU64::new(0),
        }
    }

    fn set(&self, enabled: bool, bands: [f32; 10]) -> Result<(), String> {
        if bands.iter().any(|gain| !gain.is_finite()) {
            return Err("Эквалайзер получил некорректное значение.".into());
        }
        // Odd version means a writer is publishing a new snapshot.
        self.version.fetch_add(1, Ordering::AcqRel);
        for (slot, gain) in self.gains.iter().zip(bands.iter()) {
            slot.store(gain.clamp(-12.0, 12.0).to_bits(), Ordering::Relaxed);
        }
        self.enabled.store(enabled, Ordering::Relaxed);
        self.version.fetch_add(1, Ordering::Release);
        Ok(())
    }

    fn snapshot(&self) -> (bool, [f32; 10], u64) {
        loop {
            let before = self.version.load(Ordering::Acquire);
            if before & 1 == 1 {
                std::hint::spin_loop();
                continue;
            }
            let enabled = self.enabled.load(Ordering::Relaxed);
            let gains = std::array::from_fn(|index| {
                f32::from_bits(self.gains[index].load(Ordering::Relaxed)).clamp(-12.0, 12.0)
            });
            let after = self.version.load(Ordering::Acquire);
            if before == after {
                return (enabled, gains, after);
            }
        }
    }
}

/// A sample-level native DSP source. Each EQ band owns independent filter
/// history for every interleaved channel, preventing left/right bleed.
struct EqSource<S> {
    input: S,
    shared: Arc<EqShared>,
    bands: Vec<BiquadBand>,
    enabled: bool,
    seen_version: u64,
    channels: usize,
    channel_cursor: usize,
    sample_rate: u32,
    samples_until_refresh: usize,
}

impl<S> EqSource<S>
where
    S: Source<Item = f32> + Send + 'static,
{
    fn new(input: S, shared: Arc<EqShared>) -> Self {
        let channels = usize::from(input.channels().max(1));
        let sample_rate = input.sample_rate().max(1);
        let bands = (0..EQ_FREQUENCIES.len())
            .map(|_| BiquadBand {
                coefficients: BiquadCoefficients::IDENTITY,
                states: vec![FilterState::default(); channels],
            })
            .collect();
        let mut source = Self {
            input,
            shared,
            bands,
            enabled: false,
            seen_version: 0,
            channels,
            channel_cursor: 0,
            sample_rate,
            samples_until_refresh: 0,
        };
        source.refresh_settings();
        source
    }

    fn reset_filter_state(&mut self) {
        for band in &mut self.bands {
            band.states.fill(FilterState::default());
        }
        self.channel_cursor = 0;
    }

    fn refresh_settings(&mut self) {
        let (enabled, gains, version) = self.shared.snapshot();
        if version == self.seen_version {
            return;
        }
        self.enabled = enabled;
        for (index, band) in self.bands.iter_mut().enumerate() {
            band.coefficients =
                design_biquad(index, EQ_FREQUENCIES[index], gains[index], self.sample_rate);
        }
        self.reset_filter_state();
        self.seen_version = version;
    }

    fn adapt_source_layout(&mut self) {
        let channels = usize::from(self.input.channels().max(1));
        let sample_rate = self.input.sample_rate().max(1);
        if channels != self.channels {
            self.channels = channels;
            for band in &mut self.bands {
                band.states = vec![FilterState::default(); channels];
            }
            self.channel_cursor = 0;
        }
        if sample_rate != self.sample_rate {
            self.sample_rate = sample_rate;
            self.seen_version = 0;
        }
    }
}

impl<S> Iterator for EqSource<S>
where
    S: Source<Item = f32> + Send + 'static,
{
    type Item = f32;

    fn next(&mut self) -> Option<Self::Item> {
        let input_sample = self.input.next()?;
        self.adapt_source_layout();
        if self.samples_until_refresh == 0 {
            self.refresh_settings();
            self.samples_until_refresh = EQ_REFRESH_SAMPLES;
        } else {
            self.samples_until_refresh -= 1;
        }

        let channel = self.channel_cursor;
        self.channel_cursor = (self.channel_cursor + 1) % self.channels;
        if !self.enabled {
            return Some(input_sample);
        }

        let mut sample = input_sample;
        for band in &mut self.bands {
            let state = &mut band.states[channel];
            let output = band.coefficients.b0 * sample + state.z1;
            state.z1 = band.coefficients.b1 * sample - band.coefficients.a1 * output + state.z2;
            state.z2 = band.coefficients.b2 * sample - band.coefficients.a2 * output;
            sample = output;
        }
        Some(sample)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.input.size_hint()
    }
}

impl<S> Source for EqSource<S>
where
    S: Source<Item = f32> + Send + 'static,
{
    fn current_frame_len(&self) -> Option<usize> {
        self.input.current_frame_len()
    }

    fn channels(&self) -> u16 {
        self.input.channels()
    }

    fn sample_rate(&self) -> u32 {
        self.input.sample_rate()
    }

    fn total_duration(&self) -> Option<Duration> {
        self.input.total_duration()
    }

    fn try_seek(&mut self, position: Duration) -> Result<(), rodio::source::SeekError> {
        self.input.try_seek(position)?;
        self.reset_filter_state();
        self.samples_until_refresh = 0;
        Ok(())
    }
}

/// RBJ Audio EQ Cookbook biquad coefficients: low shelf, eight peaking bands,
/// and high shelf. Frequencies are clamped below Nyquist for low-rate sources.
fn design_biquad(
    index: usize,
    frequency: f32,
    gain_db: f32,
    sample_rate: u32,
) -> BiquadCoefficients {
    if !gain_db.is_finite() || gain_db.abs() < 0.0001 {
        return BiquadCoefficients::IDENTITY;
    }

    let rate = sample_rate.max(1) as f32;
    let safe_frequency = frequency.clamp(10.0, (rate * 0.45).max(10.0));
    let omega = 2.0 * PI * safe_frequency / rate;
    let cosine = omega.cos();
    let sine = omega.sin();
    let q = if index == 0 || index == 9 { 0.72 } else { 1.05 };
    let alpha = sine / (2.0 * q);
    let amplitude = 10.0_f32.powf(gain_db.clamp(-12.0, 12.0) / 40.0);

    let (b0, b1, b2, a0, a1, a2) = if index == 0 {
        let beta = 2.0 * amplitude.sqrt() * alpha;
        (
            amplitude * ((amplitude + 1.0) - (amplitude - 1.0) * cosine + beta),
            2.0 * amplitude * ((amplitude - 1.0) - (amplitude + 1.0) * cosine),
            amplitude * ((amplitude + 1.0) - (amplitude - 1.0) * cosine - beta),
            (amplitude + 1.0) + (amplitude - 1.0) * cosine + beta,
            -2.0 * ((amplitude - 1.0) + (amplitude + 1.0) * cosine),
            (amplitude + 1.0) + (amplitude - 1.0) * cosine - beta,
        )
    } else if index == 9 {
        let beta = 2.0 * amplitude.sqrt() * alpha;
        (
            amplitude * ((amplitude + 1.0) + (amplitude - 1.0) * cosine + beta),
            -2.0 * amplitude * ((amplitude - 1.0) + (amplitude + 1.0) * cosine),
            amplitude * ((amplitude + 1.0) + (amplitude - 1.0) * cosine - beta),
            (amplitude + 1.0) - (amplitude - 1.0) * cosine + beta,
            2.0 * ((amplitude - 1.0) - (amplitude + 1.0) * cosine),
            (amplitude + 1.0) - (amplitude - 1.0) * cosine - beta,
        )
    } else {
        (
            1.0 + alpha * amplitude,
            -2.0 * cosine,
            1.0 - alpha * amplitude,
            1.0 + alpha / amplitude,
            -2.0 * cosine,
            1.0 - alpha / amplitude,
        )
    };

    if !a0.is_finite() || a0.abs() < f32::EPSILON {
        return BiquadCoefficients::IDENTITY;
    }
    let coefficients = BiquadCoefficients {
        b0: b0 / a0,
        b1: b1 / a0,
        b2: b2 / a0,
        a1: a1 / a0,
        a2: a2 / a0,
    };
    if [
        coefficients.b0,
        coefficients.b1,
        coefficients.b2,
        coefficients.a1,
        coefficients.a2,
    ]
    .iter()
    .all(|value| value.is_finite())
    {
        coefficients
    } else {
        BiquadCoefficients::IDENTITY
    }
}

fn current_status(
    playback: &Option<Playback>,
    volume: f32,
    sleep_deadline: Option<Instant>,
) -> AudioStatus {
    let sleep_timer_remaining_seconds =
        sleep_deadline.map(|deadline| deadline.saturating_duration_since(Instant::now()).as_secs());
    if let Some(p) = playback.as_ref() {
        let ended = p.sink.empty();
        let position = if ended {
            p.duration.unwrap_or_else(|| p.sink.get_pos().as_secs_f64())
        } else {
            p.sink.get_pos().as_secs_f64()
        };
        AudioStatus {
            playing: !p.sink.is_paused() && !ended,
            paused: p.sink.is_paused(),
            ended,
            path: Some(p.path.clone()),
            position,
            duration: p.duration,
            volume,
            sleep_timer_remaining_seconds,
        }
    } else {
        AudioStatus {
            playing: false,
            paused: false,
            ended: false,
            path: None,
            position: 0.0,
            duration: None,
            volume,
            sleep_timer_remaining_seconds,
        }
    }
}

fn validate_sleep_timer(seconds: Option<u64>) -> Result<Option<Instant>, String> {
    match seconds {
        Some(0) => Ok(None),
        Some(value) if value <= 14_400 => Ok(Some(Instant::now() + Duration::from_secs(value))),
        Some(_) => Err("Таймер сна не может превышать 4 часа.".into()),
        None => Ok(None),
    }
}

fn audio_worker(rx: mpsc::Receiver<Command>, eq: Arc<EqShared>) {
    let mut playback: Option<Playback> = None;
    let mut volume = 0.72_f32;
    let mut output: Option<(OutputStream, OutputStreamHandle)> = None;
    let mut sleep_deadline: Option<Instant> = None;

    loop {
        let command = match rx.recv_timeout(Duration::from_millis(200)) {
            Ok(command) => command,
            Err(mpsc::RecvTimeoutError::Timeout) => {
                if sleep_deadline.is_some_and(|deadline| Instant::now() >= deadline) {
                    if let Some(active) = playback.as_ref() {
                        active.sink.pause();
                    }
                    sleep_deadline = None;
                }
                continue;
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        };

        match command {
            Command::Play(path, reply) => {
                let result = (|| {
                    let p = Path::new(&path);
                    if !p.is_file() {
                        return Err("Аудиофайл не найден или недоступен.".into());
                    }
                    let file =
                        File::open(p).map_err(|e| format!("Не удалось открыть аудиофайл: {e}"))?;
                    let decoder = Decoder::new(BufReader::new(file))
                        .map_err(|e| format!("Формат аудио не поддерживается: {e}"))?;
                    let duration = decoder.total_duration().map(|d| d.as_secs_f64());
                    let source = EqSource::new(decoder, Arc::clone(&eq));

                    // Keep one device stream alive for the entire worker lifetime.
                    // Recreating WASAPI/CoreAudio/ALSA on every track caused avoidable
                    // device churn and occasional gaps during rapid queue changes.
                    if output.is_none() {
                        let (stream, handle) = OutputStream::try_default()
                            .map_err(|e| format!("Не удалось открыть аудиоустройство: {e}"))?;
                        output = Some((stream, handle));
                    }
                    let handle = &output.as_ref().expect("output stream initialized").1;
                    let sink = Sink::try_new(handle)
                        .map_err(|e| format!("Не удалось создать аудиопоток: {e}"))?;
                    sink.set_volume(volume);
                    sink.append(source);
                    if let Some(old) = playback.take() {
                        old.sink.stop();
                    }
                    playback = Some(Playback {
                        sink,
                        path: p.to_string_lossy().into_owned(),
                        duration,
                    });
                    Ok(current_status(&playback, volume, sleep_deadline))
                })();
                let _ = reply.send(result);
            }
            Command::Pause(reply) => {
                if let Some(p) = playback.as_ref() {
                    p.sink.pause();
                }
                let _ = reply.send(Ok(current_status(&playback, volume, sleep_deadline)));
            }
            Command::Resume(reply) => {
                if let Some(p) = playback.as_ref() {
                    p.sink.play();
                }
                let _ = reply.send(Ok(current_status(&playback, volume, sleep_deadline)));
            }
            Command::Stop(reply) => {
                if let Some(p) = playback.take() {
                    p.sink.stop();
                }
                let _ = reply.send(Ok(current_status(&playback, volume, sleep_deadline)));
            }
            Command::Seek(seconds, reply) => {
                let result = if !seconds.is_finite() || seconds < 0.0 {
                    Err("Позиция должна быть неотрицательным числом.".into())
                } else if let Some(p) = playback.as_ref() {
                    let safe_seconds = seconds.min(p.duration.unwrap_or(315_576_000.0).max(0.0));
                    p.sink
                        .try_seek(Duration::from_secs_f64(safe_seconds))
                        .map_err(|e| format!("Перемотка недоступна для этого формата: {e}"))
                        .map(|_| current_status(&playback, volume, sleep_deadline))
                } else {
                    Err("Сейчас нет активной композиции для перемотки.".into())
                };
                let _ = reply.send(result);
            }
            Command::SetVolume(value, reply) => {
                let result = if !value.is_finite() {
                    Err("Некорректная громкость.".into())
                } else {
                    volume = value.clamp(0.0, 1.0);
                    if let Some(p) = playback.as_ref() {
                        p.sink.set_volume(volume);
                    }
                    Ok(current_status(&playback, volume, sleep_deadline))
                };
                let _ = reply.send(result);
            }
            Command::SetEq(enabled, bands, reply) => {
                let result = eq
                    .set(enabled, bands)
                    .map(|_| current_status(&playback, volume, sleep_deadline));
                let _ = reply.send(result);
            }
            Command::SetSleepTimer(seconds, reply) => {
                let result = validate_sleep_timer(seconds).map(|deadline| {
                    sleep_deadline = deadline;
                    current_status(&playback, volume, sleep_deadline)
                });
                let _ = reply.send(result);
            }
            Command::Status(reply) => {
                let _ = reply.send(Ok(current_status(&playback, volume, sleep_deadline)));
            }
        }
    }
    if let Some(active) = playback.take() {
        active.sink.stop();
    }
    if let Some((stream, handle)) = output.take() {
        drop(handle);
        drop(stream);
    }
}

pub fn play(state: &AudioState, path: &str) -> Result<AudioStatus, String> {
    state.request(|reply| Command::Play(path.to_string(), reply))
}

pub fn pause(state: &AudioState) -> Result<AudioStatus, String> {
    state.request(Command::Pause)
}

pub fn resume(state: &AudioState) -> Result<AudioStatus, String> {
    state.request(Command::Resume)
}

pub fn stop(state: &AudioState) -> Result<AudioStatus, String> {
    state.request(Command::Stop)
}

pub fn seek(state: &AudioState, seconds: f64) -> Result<AudioStatus, String> {
    state.request(|reply| Command::Seek(seconds, reply))
}

pub fn set_volume(state: &AudioState, value: f32) -> Result<AudioStatus, String> {
    state.request(|reply| Command::SetVolume(value, reply))
}

pub fn set_eq(state: &AudioState, enabled: bool, bands: [f32; 10]) -> Result<AudioStatus, String> {
    state.request(|reply| Command::SetEq(enabled, bands, reply))
}

pub fn set_sleep_timer(state: &AudioState, seconds: Option<u64>) -> Result<AudioStatus, String> {
    state.request(|reply| Command::SetSleepTimer(seconds, reply))
}

pub fn status(state: &AudioState) -> Result<AudioStatus, String> {
    state.request(Command::Status)
}

#[cfg(test)]
mod tests {
    use super::*;
    use rodio::buffer::SamplesBuffer;

    #[test]
    fn zero_gain_is_an_identity_filter() {
        let identity = design_biquad(4, 1_000.0, 0.0, 44_100);
        assert_eq!(identity.b0, 1.0);
        assert_eq!(identity.b1, 0.0);
        assert_eq!(identity.b2, 0.0);
        assert_eq!(identity.a1, 0.0);
        assert_eq!(identity.a2, 0.0);
    }

    #[test]
    fn all_eq_bands_produce_finite_coefficients() {
        for index in 0..10 {
            let coefficients = design_biquad(index, EQ_FREQUENCIES[index], 12.0, 44_100);
            assert!([
                coefficients.b0,
                coefficients.b1,
                coefficients.b2,
                coefficients.a1,
                coefficients.a2
            ]
            .iter()
            .all(|value| value.is_finite()));
        }
    }

    #[test]
    fn native_eq_source_preserves_stereo_layout_and_finite_samples() {
        let shared = Arc::new(EqShared::new());
        shared
            .set(true, [3.0, 2.0, 1.0, 0.0, -1.0, -2.0, -1.0, 0.0, 1.0, 2.0])
            .unwrap();
        let input = SamplesBuffer::new(2, 44_100, vec![0.1_f32, -0.1, 0.2, -0.2, 0.0, 0.0]);
        let mut source = EqSource::new(input, shared);
        assert_eq!(source.channels(), 2);
        assert_eq!(source.sample_rate(), 44_100);
        let output = source.by_ref().collect::<Vec<_>>();
        assert_eq!(output.len(), 6);
        assert!(output.iter().all(|sample| sample.is_finite()));
    }

    #[test]
    fn eq_rejects_non_finite_band_values() {
        let shared = EqShared::new();
        let mut bands = [0.0_f32; 10];
        bands[3] = f32::NAN;
        assert!(shared.set(true, bands).is_err());
    }

    #[test]
    fn sleep_timer_accepts_cancel_and_four_hour_limit() {
        assert!(validate_sleep_timer(None).unwrap().is_none());
        assert!(validate_sleep_timer(Some(0)).unwrap().is_none());
        assert!(validate_sleep_timer(Some(1)).unwrap().is_some());
        assert!(validate_sleep_timer(Some(14_400)).unwrap().is_some());
        assert!(validate_sleep_timer(Some(14_401)).is_err());
    }
}
