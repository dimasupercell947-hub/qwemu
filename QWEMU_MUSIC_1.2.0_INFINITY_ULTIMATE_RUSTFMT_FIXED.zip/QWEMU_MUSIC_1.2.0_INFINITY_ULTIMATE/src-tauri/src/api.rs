use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use rand::{rngs::OsRng, RngCore};
use rouille::{Request, Response};
use rusqlite::{params, Connection, OptionalExtension};
use scrypt::{scrypt, Params as ScryptParams};
use serde_json::{json, Map, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    fs,
    io::Read,
    path::{Component, Path, PathBuf},
    sync::{Arc, Mutex, OnceLock},
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

const VERSION: &str = "1.2.0";
const COOKIE: &str = "QWEMU_SESSION";
const MAX_BODY: usize = 1024 * 1024;
const SESSION_SECONDS: i64 = 30 * 86400;

#[derive(Clone)]
pub struct ApiConfig {
    pub data_dir: PathBuf,
    pub assets_dir: PathBuf,
}

fn now() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}
fn db(path: &Path) -> Result<Connection, String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let c = Connection::open(path).map_err(|e| e.to_string())?;
    c.execute_batch("PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=15000;")
        .map_err(|e| e.to_string())?;
    Ok(c)
}
fn init_db(path: &Path) -> Result<(), String> {
    let c = db(path)?;
    c.execute_batch("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, email TEXT UNIQUE COLLATE NOCASE, display_name TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '', password_salt BLOB NOT NULL, password_hash BLOB NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, sync_version INTEGER NOT NULL DEFAULT 0, sync_data TEXT NOT NULL DEFAULT '{}');
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id); CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);") .map_err(|e| e.to_string())?;
    let has_bio: bool = c
        .query_row(
            "SELECT EXISTS(SELECT 1 FROM pragma_table_info('users') WHERE name='bio')",
            [],
            |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    if !has_bio {
        c.execute(
            "ALTER TABLE users ADD COLUMN bio TEXT NOT NULL DEFAULT ''",
            [],
        )
        .map_err(|e| e.to_string())?;
    }
    c.execute("DELETE FROM sessions WHERE expires_at < ?1", [now()])
        .map_err(|e| e.to_string())?;
    Ok(())
}
fn hash_password(password: &str, salt: &[u8]) -> Result<Vec<u8>, String> {
    let params = ScryptParams::new(14, 8, 1, 64).map_err(|e| e.to_string())?;
    let mut out = vec![0u8; 64];
    scrypt(password.as_bytes(), salt, &params, &mut out).map_err(|e| e.to_string())?;
    Ok(out)
}
fn sha(value: &str) -> String {
    hex::encode(Sha256::digest(value.as_bytes()))
}
fn random_token(bytes: usize) -> String {
    let mut b = vec![0u8; bytes];
    OsRng.fill_bytes(&mut b);
    URL_SAFE_NO_PAD.encode(b)
}
fn user_json(c: &Connection, id: &str) -> Result<Value, String> {
    let row = c.query_row("SELECT id,username,display_name,COALESCE(email,''),COALESCE(bio,''),created_at FROM users WHERE id=?1", [id], |r| Ok(json!({"id":r.get::<_,String>(0)?,"username":r.get::<_,String>(1)?,"displayName":r.get::<_,String>(2)?,"email":r.get::<_,String>(3)?,"bio":r.get::<_,String>(4)?,"createdAt":r.get::<_,i64>(5)? * 1000}))).map_err(|e| e.to_string())?;
    Ok(row)
}
fn body(req: &Request) -> Result<Value, String> {
    let reader = req.data().ok_or("Отсутствует тело запроса.")?;
    let mut bytes = Vec::new();
    reader
        .take((MAX_BODY + 1) as u64)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.is_empty() || bytes.len() > MAX_BODY {
        return Err("Размер запроса должен быть от 1 байта до 1 МБ.".into());
    }
    let v: Value =
        serde_json::from_slice(&bytes).map_err(|_| "Тело запроса должно быть корректным JSON.")?;
    if !v.is_object() {
        return Err("Ожидался JSON-объект.".into());
    }
    Ok(v)
}
fn cookie_token(req: &Request) -> Option<String> {
    req.header("Cookie")?.split(';').find_map(|part| {
        let (k, v) = part.trim().split_once('=')?;
        if k == COOKIE {
            Some(v.to_string())
        } else {
            None
        }
    })
}
fn session_user(c: &Connection, req: &Request) -> Result<Option<String>, String> {
    let Some(token) = cookie_token(req) else {
        return Ok(None);
    };
    c.query_row(
        "SELECT user_id FROM sessions WHERE token_hash=?1 AND expires_at>?2",
        params![sha(&token), now()],
        |r| r.get(0),
    )
    .optional()
    .map_err(|e| e.to_string())
}
fn json_response(status: u16, value: Value) -> Response {
    Response::json(&value)
        .with_status_code(status)
        .with_additional_header("Cache-Control", "no-store")
        .with_additional_header("X-Content-Type-Options", "nosniff")
        .with_additional_header("X-Frame-Options", "DENY")
        .with_additional_header(
            "Permissions-Policy",
            "camera=(), microphone=(), geolocation=()",
        )
        .with_additional_header("Referrer-Policy", "same-origin")
}
fn error(status: u16, message: impl Into<String>) -> Response {
    json_response(status, json!({"error":message.into()}))
}
fn set_session(c: &Connection, user_id: &str) -> Result<String, String> {
    let token = random_token(40);
    let n = now();
    c.execute(
        "INSERT INTO sessions(token_hash,user_id,created_at,expires_at) VALUES(?1,?2,?3,?4)",
        params![sha(&token), user_id, n, n + SESSION_SECONDS],
    )
    .map_err(|e| e.to_string())?;
    c.execute(
        "DELETE FROM sessions WHERE user_id=?1 AND expires_at<?2",
        params![user_id, n],
    )
    .map_err(|e| e.to_string())?;
    c.execute("DELETE FROM sessions WHERE user_id=?1 AND token_hash NOT IN (SELECT token_hash FROM sessions WHERE user_id=?1 ORDER BY created_at DESC LIMIT 10)", [user_id]).map_err(|e| e.to_string())?;
    Ok(token)
}
fn valid_email(s: &str) -> bool {
    let mut p = s.split('@');
    matches!((p.next(),p.next(),p.next()),(Some(a),Some(b),None) if !a.is_empty() && !s.chars().any(char::is_whitespace) && b.contains('.') && !b.starts_with('.') && !b.ends_with('.'))
}
static AUTH_RATE: OnceLock<Mutex<HashMap<String, Vec<i64>>>> = OnceLock::new();
fn auth_rate_allowed(req: &Request) -> bool {
    let key = req.remote_addr().ip().to_string();
    let now = now();
    let map = AUTH_RATE.get_or_init(|| Mutex::new(HashMap::new()));
    let Ok(mut guard) = map.lock() else {
        return false;
    };
    let entries = guard.entry(key).or_default();
    entries.retain(|stamp| now - *stamp < 60);
    if entries.len() >= 12 {
        return false;
    }
    entries.push(now);
    true
}
fn norm_sync(v: &Value) -> Result<Value, String> {
    let o = v.as_object().ok_or("Поле data должно быть объектом.")?;
    let list = |key: &str, max: usize| -> Result<Vec<Value>, String> {
        let a = o.get(key).cloned().unwrap_or(json!([]));
        let a = a
            .as_array()
            .ok_or_else(|| format!("Некорректное поле {key}."))?;
        if a.len() > max {
            return Err(format!("Некорректное поле {key}."));
        }
        Ok(a.clone())
    };
    let favorites = list("favorites", 5000)?;
    let history = list("history", 5000)?;
    let searches = list("searchHistory", 30)?;
    let queue = list("queueIds", 5000)?;
    let playlists = list("playlists", 500)?;
    let prefs = o.get("prefs").cloned().unwrap_or(json!({}));
    if !prefs.is_object() {
        return Err("Некорректные настройки.".into());
    }
    let strings = |items: Vec<Value>, max: usize| -> Vec<Value> {
        let mut out = Vec::new();
        for x in items {
            if x.is_string() || x.is_number() {
                let s = if let Some(text) = x.as_str() {
                    text.to_owned()
                } else {
                    x.to_string()
                };
                let s = s.chars().take(max).collect::<String>();
                let v = Value::String(s);
                if !out.contains(&v) {
                    out.push(v);
                }
            }
        }
        out
    };
    let mut clean = Vec::new();
    for p in playlists {
        if let Some(p) = p.as_object() {
            let id = p
                .get("id")
                .and_then(Value::as_str)
                .unwrap_or("")
                .chars()
                .take(100)
                .collect::<String>();
            let name = p
                .get("name")
                .and_then(Value::as_str)
                .unwrap_or("")
                .trim()
                .chars()
                .take(80)
                .collect::<String>();
            let ids = p
                .get("trackIds")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            if !id.is_empty() && !name.is_empty() {
                clean.push(json!({"id":id,"name":name,"description":p.get("description").and_then(Value::as_str).unwrap_or("").chars().take(180).collect::<String>(),"cover":p.get("cover").and_then(Value::as_str).unwrap_or("").chars().take(500).collect::<String>(),"trackIds":strings(ids.into_iter().take(2000).collect(),160)}));
            }
        }
    }
    let mut clean_prefs = Map::new();
    for (k, val) in prefs.as_object().unwrap() {
        if val.is_string() || val.is_number() || val.is_boolean() || val.is_null() {
            clean_prefs.insert(k.chars().take(80).collect(), val.clone());
            if clean_prefs.len() >= 100 {
                break;
            }
        }
    }
    let volume = o
        .get("volume")
        .and_then(Value::as_f64)
        .unwrap_or(0.72)
        .clamp(0.0, 1.0);
    let qi = o
        .get("queueIndex")
        .and_then(Value::as_i64)
        .unwrap_or(0)
        .clamp(0, 5000);
    let repeat = match o.get("repeat") {
        Some(Value::Bool(b)) => json!(b),
        Some(Value::String(s)) if s == "one" || s == "all" => json!(s),
        _ => json!(false),
    };
    Ok(
        json!({"favorites":strings(favorites,160),"history":strings(history,160),"searchHistory":strings(searches.into_iter().filter(|x|x.is_string()).collect(),120),"queueIds":strings(queue,160),"queueIndex":qi,"playlists":clean,"prefs":clean_prefs,"shuffle":o.get("shuffle").and_then(Value::as_bool).unwrap_or(false),"repeat":repeat,"volume":volume}),
    )
}
fn static_file(root: &Path, path: &str) -> Response {
    let decoded = path.trim_start_matches('/');
    let rel = Path::new(if decoded.is_empty() {
        "index.html"
    } else {
        decoded
    });
    if rel.components().any(|c| !matches!(c, Component::Normal(_)))
        || rel
            .components()
            .any(|c| c.as_os_str().to_string_lossy().starts_with('.'))
    {
        return error(404, "Файл не найден.");
    }
    let allowed = [
        "html", "css", "js", "mjs", "json", "png", "jpg", "jpeg", "webp", "gif", "svg", "ico",
        "woff", "woff2", "ttf",
    ];
    if !rel
        .extension()
        .and_then(|x| x.to_str())
        .map(|x| allowed.contains(&x.to_lowercase().as_str()))
        .unwrap_or(false)
    {
        return error(404, "Файл не найден.");
    }
    let file = root.join(rel);
    let Ok(canon) = file.canonicalize() else {
        return error(404, "Файл не найден.");
    };
    if !canon.starts_with(root) {
        return error(404, "Файл не найден.");
    }
    let Ok(bytes) = fs::read(&canon) else {
        return error(404, "Файл не найден.");
    };
    let mime = mime_guess::from_path(&canon)
        .first_raw()
        .unwrap_or("application/octet-stream");
    Response::from_data(mime, bytes)
        .with_status_code(200)
        .with_additional_header("X-Content-Type-Options", "nosniff")
        .with_additional_header("X-Frame-Options", "DENY")
        .with_additional_header(
            "Permissions-Policy",
            "camera=(), microphone=(), geolocation=()",
        )
        .with_additional_header("Referrer-Policy", "same-origin")
        .with_additional_header(
            "Cache-Control",
            if canon.extension().and_then(|x| x.to_str()) == Some("html")
                || canon.extension().and_then(|x| x.to_str()) == Some("json")
            {
                "no-cache"
            } else {
                "public, max-age=86400"
            },
        )
}
fn handle(req: &Request, cfg: &ApiConfig, db_path: &Path) -> Response {
    let request_url = req.url();
    let path = request_url.split('?').next().unwrap_or("/");
    let method = req.method();
    if !path.starts_with("/api/") {
        return static_file(&cfg.assets_dir, path);
    }
    if method == "GET" && path == "/api/health" {
        return json_response(
            200,
            json!({"ok":true,"service":"QWEMU PC API","version":VERSION,"database":"sqlite","auth":true,"sync":true,"musicCatalog":{"configured":false,"message":"Лицензированный потоковый провайдер пока не подключён."}}),
        );
    }
    if method == "GET" && path == "/api/catalog/status" {
        return json_response(
            200,
            json!({"providerConfigured":false,"localLibrary":true,"message":"Глобальный потоковый каталог не подключён. Доступны локальные файлы и каталоги с подходящими лицензиями."}),
        );
    }
    if method == "GET" && path == "/api/catalog/search" {
        let q = request_url
            .split("q=")
            .nth(1)
            .unwrap_or("")
            .split('&')
            .next()
            .unwrap_or("");
        return json_response(
            200,
            json!({"query":q,"items":[],"providerConfigured":false,"message":"Онлайн-провайдер каталога не подключён; открой «Открытая музыка» для поиска лицензируемых материалов."}),
        );
    }
    let c = match db(db_path) {
        Ok(c) => c,
        Err(e) => return error(500, e),
    };
    if method == "GET" && path == "/api/me" {
        let Some(uid) = session_user(&c, req).ok().flatten() else {
            return error(401, "Требуется авторизация.");
        };
        return match user_json(&c, &uid) {
            Ok(u) => json_response(200, json!({"user":u})),
            Err(e) => error(500, e),
        };
    }
    if method == "GET" && path == "/api/sync" {
        let Some(uid) = session_user(&c, req).ok().flatten() else {
            return error(401, "Требуется авторизация.");
        };
        let row = c.query_row(
            "SELECT sync_data,sync_version,updated_at FROM users WHERE id=?1",
            [uid],
            |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, i64>(1)?,
                    r.get::<_, i64>(2)?,
                ))
            },
        );
        return match row {
            Ok((data, ver, updated)) => {
                let val = serde_json::from_str(&data).unwrap_or(json!({}));
                match norm_sync(&val) {
                    Ok(data) => json_response(
                        200,
                        json!({"data":data,"version":ver,"updatedAt":updated*1000}),
                    ),
                    Err(e) => error(500, e),
                }
            }
            Err(e) => error(401, e.to_string()),
        };
    }
    if method == "POST" {
        if (path == "/api/auth/register" || path == "/api/auth/login") && !auth_rate_allowed(req) {
            return error(
                429,
                "Слишком много попыток. Подожди минуту и попробуй снова.",
            );
        }
        let b = match body(req) {
            Ok(b) => b,
            Err(e) => return error(400, e),
        };
        if path == "/api/auth/register" {
            let username = b["username"].as_str().unwrap_or("").trim().to_lowercase();
            let display = b["displayName"].as_str().unwrap_or("").trim();
            let email = b["email"].as_str().unwrap_or("").trim().to_lowercase();
            let password = b["password"].as_str().unwrap_or("");
            if username.len() < 3
                || username.len() > 20
                || !username
                    .chars()
                    .all(|x| x.is_ascii_lowercase() || x.is_ascii_digit() || x == '_')
            {
                return error(
                    400,
                    "Имя пользователя: 3–20 символов, латиница, цифры и _. ",
                );
            }
            if display.chars().count() < 2 || display.chars().count() > 32 {
                return error(400, "Имя должно содержать от 2 до 32 символов.");
            };
            if !email.is_empty() && (email.len() > 160 || !valid_email(&email)) {
                return error(400, "Проверь адрес электронной почты.");
            };
            if password.len() < 8 || password.len() > 128 {
                return error(400, "Пароль должен содержать от 8 до 128 символов.");
            }
            let mut salt = [0u8; 16];
            OsRng.fill_bytes(&mut salt);
            let digest = match hash_password(password, &salt) {
                Ok(x) => x,
                Err(e) => return error(500, e),
            };
            let uid = random_token(18);
            let n = now();
            let result=c.execute("INSERT INTO users(id,username,email,display_name,password_salt,password_hash,created_at,updated_at,sync_data) VALUES(?1,?2,?3,?4,?5,?6,?7,?7,'{}')",params![uid,username,if email.is_empty(){None}else{Some(email)},display,salt.to_vec(),digest,n]);
            if result.is_err() {
                return error(
                    409,
                    "Имя пользователя или электронная почта уже зарегистрированы.",
                );
            };
            let token = match set_session(&c, &uid) {
                Ok(t) => t,
                Err(e) => return error(500, e),
            };
            let user = user_json(&c, &uid).unwrap_or(json!({}));
            return json_response(201,json!({"user":user})).with_additional_header("Set-Cookie",format!("{COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}"));
        }
        if path == "/api/auth/login" {
            let username = b["username"].as_str().unwrap_or("").trim();
            let password = b["password"].as_str().unwrap_or("");
            if username.len() > 20 || password.is_empty() || password.len() > 128 {
                return error(400, "Проверь имя пользователя и пароль.");
            }
            let row=c.query_row("SELECT id,password_salt,password_hash FROM users WHERE username=?1 COLLATE NOCASE",[username],|r|Ok((r.get::<_,String>(0)?,r.get::<_,Vec<u8>>(1)?,r.get::<_,Vec<u8>>(2)?))).optional();
            let Ok(Some((uid, salt, expected))) = row else {
                return error(401, "Неверное имя пользователя или пароль.");
            };
            let actual = match hash_password(password, &salt) {
                Ok(x) => x,
                Err(e) => return error(500, e),
            };
            if actual.len() != expected.len()
                || actual
                    .iter()
                    .zip(expected.iter())
                    .fold(0u8, |a, (x, y)| a | (x ^ y))
                    != 0
            {
                return error(401, "Неверное имя пользователя или пароль.");
            };
            let token = match set_session(&c, &uid) {
                Ok(t) => t,
                Err(e) => return error(500, e),
            };
            let user = user_json(&c, &uid).unwrap_or(json!({}));
            return json_response(200,json!({"user":user})).with_additional_header("Set-Cookie",format!("{COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}"));
        }
        if path == "/api/auth/logout" {
            if let Some(token) = cookie_token(req) {
                let _ = c.execute("DELETE FROM sessions WHERE token_hash=?1", [sha(&token)]);
            }
            return json_response(200, json!({"ok":true})).with_additional_header(
                "Set-Cookie",
                format!("{COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"),
            );
        }
        return error(404, "API endpoint не найден.");
    }
    if method == "PUT" && (path == "/api/me" || path == "/api/sync") {
        let Some(uid) = session_user(&c, req).ok().flatten() else {
            return error(401, "Требуется авторизация.");
        };
        let b = match body(req) {
            Ok(b) => b,
            Err(e) => return error(400, e),
        };
        let n = now();
        if path == "/api/me" {
            let display = b["displayName"].as_str().unwrap_or("").trim();
            let email = b["email"].as_str().unwrap_or("").trim().to_lowercase();
            let bio = b["bio"]
                .as_str()
                .unwrap_or("")
                .chars()
                .take(180)
                .collect::<String>();
            if display.chars().count() < 2 || display.chars().count() > 32 {
                return error(400, "Имя должно содержать от 2 до 32 символов.");
            };
            if !email.is_empty() && (email.len() > 160 || !valid_email(&email)) {
                return error(400, "Проверь адрес электронной почты.");
            };
            let res = c.execute(
                "UPDATE users SET display_name=?1,email=?2,bio=?3,updated_at=?4 WHERE id=?5",
                params![
                    display,
                    if email.is_empty() { None } else { Some(email) },
                    bio,
                    n,
                    uid
                ],
            );
            if res.is_err() {
                return error(409, "Эта электронная почта уже используется.");
            };
            return match user_json(&c, &uid) {
                Ok(u) => json_response(200, json!({"user":u})),
                Err(e) => error(500, e),
            };
        }
        let data = match norm_sync(&b["data"]) {
            Ok(x) => x,
            Err(e) => return error(400, e),
        };
        let current = c
            .query_row("SELECT sync_version FROM users WHERE id=?1", [&uid], |r| {
                r.get::<_, i64>(0)
            })
            .unwrap_or(0);
        let base = b.get("baseVersion").and_then(Value::as_i64);
        if let Some(base) = base {
            if base != current {
                let row = c.query_row(
                    "SELECT sync_data,sync_version,updated_at FROM users WHERE id=?1",
                    [&uid],
                    |r| {
                        Ok((
                            r.get::<_, String>(0)?,
                            r.get::<_, i64>(1)?,
                            r.get::<_, i64>(2)?,
                        ))
                    },
                );
                if let Ok((raw, v, t)) = row {
                    let latest = norm_sync(&serde_json::from_str(&raw).unwrap_or(json!({})))
                        .unwrap_or(json!({}));
                    return json_response(
                        409,
                        json!({"conflict":true,"data":latest,"version":v,"updatedAt":t*1000}),
                    );
                }
            }
        }
        let newv = current + 1;
        let raw = serde_json::to_string(&data).unwrap_or_else(|_| "{}".into());
        if let Err(e) = c.execute(
            "UPDATE users SET sync_data=?1,sync_version=?2,updated_at=?3 WHERE id=?4",
            params![raw, newv, n, uid],
        ) {
            return error(500, e.to_string());
        };
        return json_response(
            200,
            json!({"ok":true,"data":data,"version":newv,"updatedAt":n*1000}),
        );
    }
    if method == "DELETE" && path == "/api/me" {
        let Some(uid) = session_user(&c, req).ok().flatten() else {
            return error(401, "Требуется авторизация.");
        };
        if let Err(e) = c.execute("DELETE FROM users WHERE id=?1", [uid]) {
            return error(500, e.to_string());
        };
        return json_response(200, json!({"ok":true})).with_additional_header(
            "Set-Cookie",
            format!("{COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"),
        );
    }
    error(404, "API endpoint не найден.")
}

pub fn start(cfg: ApiConfig) -> Result<(), String> {
    fs::create_dir_all(&cfg.data_dir).map_err(|e| e.to_string())?;
    let db_path = cfg.data_dir.join("qwemu.sqlite3");
    init_db(&db_path)?;
    let assets = cfg
        .assets_dir
        .canonicalize()
        .map_err(|e| format!("Каталог интерфейса не найден: {e}"))?;
    let cfg = Arc::new(ApiConfig {
        data_dir: cfg.data_dir.clone(),
        assets_dir: assets,
    });
    let dbp = Arc::new(db_path);
    // Bind synchronously before spawning the worker. If another process already
    // owns port 8765, return that error instead of mistaking its TCP listener
    // for a successfully started QWEMU API.
    let server = rouille::Server::new("127.0.0.1:8765", move |req| handle(req, &cfg, &dbp))
        .map_err(|e| format!("Не удалось открыть локальный API QWEMU на 127.0.0.1:8765: {e}"))?;
    thread::Builder::new()
        .name("qwemu-rust-api".into())
        .spawn(move || server.run())
        .map_err(|e| format!("Не удалось запустить поток локального API QWEMU: {e}"))?;
    for _ in 0..80 {
        if std::net::TcpStream::connect("127.0.0.1:8765").is_ok() {
            return Ok(());
        }
        thread::sleep(Duration::from_millis(100));
    }
    Err("Rust API не запустился за 8 секунд.".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sync_payload_is_sanitized_and_bounded() {
        let input = json!({"favorites":["a","a",7],"history":[],"searchHistory":["  "],"queueIds":["x"],"queueIndex":99999,"playlists":[{"id":"p1","name":" Mix ","trackIds":["a","b"]}],"prefs":{"theme":"dark","bad":[]},"shuffle":true,"repeat":"all","volume":4.0});
        let out = norm_sync(&input).expect("valid sync payload");
        assert_eq!(out["favorites"].as_array().unwrap().len(), 2);
        assert_eq!(out["queueIndex"], 5000);
        assert_eq!(out["volume"], 1.0);
        assert_eq!(out["playlists"][0]["name"], "Mix");
        assert_eq!(out["prefs"].get("bad"), None);
    }
    #[test]
    fn sync_rejects_wrong_types_and_oversized_arrays() {
        assert!(norm_sync(&json!({"favorites":"not-array"})).is_err());
        let huge = vec![json!("x"); 5001];
        assert!(norm_sync(&json!({"favorites":huge})).is_err());
    }
    #[test]
    fn scrypt_hash_is_compatible_length_and_salted() {
        let salt = [7u8; 16];
        let a = hash_password("qwemu-test-password", &salt).unwrap();
        let b = hash_password("qwemu-test-password", &salt).unwrap();
        let c = hash_password("other-password", &salt).unwrap();
        assert_eq!(a.len(), 64);
        assert_eq!(a, b);
        assert_ne!(a, c);
    }
}
